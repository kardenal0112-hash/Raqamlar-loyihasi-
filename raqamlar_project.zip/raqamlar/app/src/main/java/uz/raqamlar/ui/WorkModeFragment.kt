package uz.raqamlar.ui

import android.os.Bundle
import android.view.*
import android.widget.Button
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R

class WorkModeFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_work_mode, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility("Ish tartibi")
        view.findViewById<Button>(R.id.btnJadval).setOnClickListener {
            (activity as MainActivity).navigateTo(ScheduleListFragment())
        }
        view.findViewById<Button>(R.id.btnJoylashuv).setOnClickListener {
            (activity as MainActivity).navigateTo(LocationListFragment())
        }
    }
}
