package uz.raqamlar.utils

object SumUtils {
    private val units = arrayOf("", "bir", "ikki", "uch", "to'rt", "besh", "olti", "yetti", "sakkiz", "to'qqiz")
    private val tens = arrayOf("", "o'n", "yigirma", "o'ttiz", "qirq", "ellik", "oltmish", "yetmish", "sakson", "to'qson")

    fun sumToWords(num: String): String {
        val n = num.toLongOrNull() ?: return ""
        if (n == 0L) return ""
        return convert(n).trim().replace(Regex("\\s+"), " ") + " so'm"
    }

    private fun convert(n0: Long): String {
        var n = n0
        var res = ""
        if (n >= 1000000L) {
            res = convert(n / 1000000L) + " million "
            n %= 1000000L
        }
        if (n >= 1000L) {
            res += convert(n / 1000L) + " ming "
            n %= 1000L
        }
        if (n >= 100L) {
            res += units[(n / 100L).toInt()] + " yuz "
            n %= 100L
        }
        if (n >= 10L) {
            res += tens[(n / 10L).toInt()] + " "
            n %= 10L
        }
        if (n > 0L) {
            res += units[n.toInt()]
        }
        return res
    }
}
