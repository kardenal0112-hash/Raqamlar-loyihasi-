package uz.raqamlar.utils

import android.content.Context
import android.widget.Toast

object Say {
    fun show(ctx: Context, msg: String, long: Boolean = false) {
        Toast.makeText(ctx, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }
}
