package uz.raqamlar.utils

// To'lov jarayonida karta/telefon raqami va summa vaqtincha operativ xotirada turadi.
// (Bank ilovasi maydoniga joylash maxsus imkoniyatlar xizmati qo'shilganda ishlaydi.)
object PaymentSession {
    var data: String? = null
    var summa: String? = null

    fun clear() {
        data = null
        summa = null
    }
}
