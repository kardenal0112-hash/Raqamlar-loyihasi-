package uz.raqamlar.utils

object TextUtils {

    private val CYRILLIC_UPPER_TO_LOWER = mapOf(
        'А' to 'а', 'Б' to 'б', 'В' to 'в', 'Г' to 'г', 'Д' to 'д',
        'Е' to 'е', 'Ё' to 'ё', 'Ж' to 'ж', 'З' to 'з', 'И' to 'и',
        'Й' to 'й', 'К' to 'к', 'Л' to 'л', 'М' to 'м', 'Н' to 'н',
        'О' to 'о', 'П' to 'п', 'Р' to 'р', 'С' to 'с', 'Т' to 'т',
        'У' to 'у', 'Ф' to 'ф', 'Х' to 'х', 'Ц' to 'ц', 'Ч' to 'ч',
        'Ш' to 'ш', 'Щ' to 'щ', 'Ы' to 'ы', 'Э' to 'э', 'Ю' to 'ю', 'Я' to 'я'
    )

    private val CYRILLIC_LOWER_TO_UPPER = mapOf(
        'а' to 'А', 'б' to 'Б', 'в' to 'В', 'г' to 'Г', 'д' to 'Д',
        'е' to 'Е', 'ё' to 'Ё', 'ж' to 'Ж', 'з' to 'З', 'и' to 'И',
        'й' to 'Й', 'к' to 'К', 'л' to 'Л', 'м' to 'М', 'н' to 'Н',
        'о' to 'О', 'п' to 'П', 'р' to 'Р', 'с' to 'С', 'т' to 'Т',
        'у' to 'У', 'ф' to 'Ф', 'х' to 'Х', 'ц' to 'Ц', 'ч' to 'Ч',
        'ш' to 'Ш', 'щ' to 'Щ', 'ы' to 'Ы', 'э' to 'Э', 'ю' to 'Ю', 'я' to 'Я'
    )

    fun toLowerCustom(s: String): String = buildString {
        for (c in s) append(CYRILLIC_UPPER_TO_LOWER[c] ?: c.lowercaseChar())
    }

    fun capitalizeFirst(s: String): String {
        val t = s.trimStart()
        if (t.isEmpty()) return ""
        val first = t[0]
        val upper = CYRILLIC_LOWER_TO_UPPER[first] ?: first.uppercaseChar()
        return upper + t.substring(1)
    }

    // Lotin-kirill to'qnashuvini bartaraf qiluvchi skeleton funksiyasi
    fun getSkel(s: String): String {
        if (s.isEmpty()) return ""

        // 1-qadam: kichik harfga o'tkazish + "u/у/о" -> "o" normallashtirish
        val normalized = buildString {
            for (c in toLowerCustom(s)) {
                append(when (c) {
                    'у', 'о', 'u' -> 'o'
                    else -> c
                })
            }
        }

        // 2-qadam: tutuq belgisini normallashtirish
        val r = normalized
            .replace(Regex("[o][''`\u2018\u2019]"), "o")
            .replace(Regex("[g][''`\u2018\u2019]"), "g")

        // 3-qadam: transliteratsiya
        val translitMap = mapOf(
            "ш" to "sh", "ч" to "ch", "ё" to "yo", "ю" to "yu", "я" to "ya",
            "ў" to "o", "ғ" to "g", "қ" to "k", "ҳ" to "h",
            "а" to "a", "б" to "b", "в" to "v", "г" to "g", "д" to "d",
            "е" to "e", "ж" to "j", "з" to "z", "и" to "i", "й" to "y",
            "к" to "k", "л" to "l", "м" to "m", "н" to "n", "о" to "o",
            "п" to "p", "р" to "r", "с" to "s", "т" to "t", "у" to "o",
            "ф" to "f", "ц" to "ts", "э" to "e", "х" to "h"
        )

        val sb = StringBuilder()
        var i = 0
        while (i < r.length) {
            var matched = false
            if (i + 1 < r.length) {
                val two = r.substring(i, i + 2)
                translitMap[two]?.let { sb.append(it); i += 2; matched = true }
            }
            if (!matched) {
                val one = r[i].toString()
                sb.append(translitMap[one] ?: one)
                i++
            }
        }

        return sb.toString()
            .replace(Regex("[^a-z0-9]"), "")
            .replace('x', 'h')
            .replace('q', 'k')
    }

    fun isValidLuhn(cardNum: String): Boolean {
        if (cardNum.length != 16 || !cardNum.all { it.isDigit() }) return false
        var sum = 0
        for (i in cardNum.indices) {
            var digit = cardNum[i].digitToInt()
            if ((cardNum.length - 1 - i) % 2 == 1) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
        }
        return sum % 10 == 0
    }

    fun getBankName(num: String): String {
        if (num.length < 4) return "Karta"
        val b4 = num.substring(0, 4)
        return when {
            b4 == "8600" || b4 == "5614" -> "Uzcard"
            b4 == "9860" || b4 == "5561" -> "Humo"
            b4 == "6262" -> "UnionPay"
            num[0] == '4' -> "Visa"
            num[0] == '5' -> "Mastercard"
            num[0] == '2' -> "Mir"
            else -> "Karta"
        }
    }

    fun formatPhoneForVoice(num: String): String {
        return if (num.matches(Regex("\\+998\\d{9}"))) {
            "${num.substring(0,4)}. ${num.substring(4,6)}. " +
            "${num.substring(6,9)}. ${num.substring(9,11)}-${num.substring(11,13)}."
        } else num
    }

    fun formatCardForVoice(num: String): String = buildString {
        for (i in num.indices step 4) {
            val block = num.substring(i, minOf(i + 4, num.length))
            if (block.length == 4) append("${block.substring(0,2)}-${block.substring(2,4)}. ")
            else append("$block. ")
        }
    }.trimEnd()

    fun normalizeToFullPhone(input: String): String? {
        val digits = input.replace(Regex("[^\\d]"), "")
        return when {
            digits.length == 9 -> "+998$digits"
            digits.length == 12 && digits.startsWith("998") -> "+$digits"
            else -> null
        }
    }

    fun findAllPhones(text: String): List<String> {
        val seen = mutableSetOf<String>()
        val results = mutableListOf<String>()
        val noTime = text
            .replace(Regex("\\d{1,2}\\s?:\\s?\\d{2}"), " ")
            .replace(Regex("\\d{2}\\.\\d{2}\\.\\d{4}"), " ")

        Regex("[+][\\d\\s\\-()`.'\"\\[\\]{}]+").findAll(noTime).forEach { m ->
            val clean = m.value.replace(Regex("[^\\d]"), "")
            if (clean.length >= 12) {
                val num = "+${clean.substring(0, 12)}"
                if (seen.add(num)) results.add(num)
            }
        }
        Regex("[\\d\\s\\-()`.'\"\\[\\]{}]+").findAll(noTime).forEach { m ->
            val clean = m.value.replace(Regex("[^\\d]"), "")
            when {
                clean.length == 9 -> { val n = "+998$clean"; if (seen.add(n)) results.add(n) }
                clean.length == 12 && clean.startsWith("998") -> {
                    val n = "+$clean"; if (seen.add(n)) results.add(n)
                }
            }
        }
        return results
    }

    fun findAllCards(text: String): List<Pair<String, String>> {
        val clean = text.replace(Regex("[\\s.\\-]"), "")
        return Regex("\\d{16}").findAll(clean).map { Pair(it.value, getBankName(it.value)) }.toList()
    }
}
