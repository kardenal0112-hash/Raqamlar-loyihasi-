package uz.raqamlar.data

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

data class LocationEntry(
    val name: String,
    val lat: Double,
    val lon: Double,
    val radius: Int,
    val mode: String
)

object LocationRepo {
    private const val PREFS = "ish_tartibi_joylashuv_data"
    private const val KEY   = "location_json"
    private const val MAX_AGE_MS = 2 * 60 * 60 * 1000L // 2 soat

    fun getAll(ctx: Context): MutableList<LocationEntry> {
        val json = ctx.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val list = mutableListOf<LocationEntry>()
        return try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(LocationEntry(
                    o.getString("name"), o.getDouble("lat"), o.getDouble("lon"),
                    o.optInt("radius", 150), o.getString("mode")
                ))
            }
            list
        } catch (e: Exception) { list }
    }

    fun saveAll(ctx: Context, list: List<LocationEntry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().apply {
                put("name", e.name); put("lat", e.lat); put("lon", e.lon)
                put("radius", e.radius); put("mode", e.mode)
            })
        }
        ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED

    fun getCachedLocation(ctx: Context): Location? {
        if (!hasPermission(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val nowMs = System.currentTimeMillis()
        var best: Location? = null
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .forEach { prov ->
                try {
                    val loc = lm.getLastKnownLocation(prov) ?: return@forEach
                    if (nowMs - loc.time > MAX_AGE_MS) return@forEach
                    if (best == null || loc.accuracy < best!!.accuracy) best = loc
                } catch (_: Exception) {}
            }
        return best
    }

    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371000.0
        val rad = Math.PI / 180
        val dLat = (lat2 - lat1) * rad
        val dLon = (lon2 - lon1) * rad
        val a = sin(dLat/2).pow(2) + cos(lat1*rad) * cos(lat2*rad) * sin(dLon/2).pow(2)
        return R * 2 * atan2(sqrt(a), sqrt(1-a))
    }

    fun checkMode(ctx: Context): String? {
        if (!hasPermission(ctx)) return null
        val loc = getCachedLocation(ctx) ?: return null
        return computeMode(loc.latitude, loc.longitude, getAll(ctx))
    }

    fun computeMode(lat: Double, lon: Double, entries: List<LocationEntry>): String? {
        var bestMode: String? = null
        var bestDist = Double.MAX_VALUE
        entries.forEach { e ->
            val dist = distanceMeters(lat, lon, e.lat, e.lon)
            if (dist <= e.radius && dist < bestDist) { bestDist = dist; bestMode = e.mode }
        }
        return bestMode
    }
}
