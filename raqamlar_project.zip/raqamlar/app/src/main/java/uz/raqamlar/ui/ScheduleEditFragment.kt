package uz.raqamlar.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.R
import uz.raqamlar.data.ScheduleEntry
import uz.raqamlar.data.ScheduleRepo

class ScheduleEditFragment : Fragment() {

    companion object {
        fun newInstance(index: Int, mode: String?) = ScheduleEditFragment().apply {
            arguments = Bundle().apply {
                putInt("index", index)
                mode?.let { putString("mode", it) }
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_schedule_edit, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val index = arguments?.getInt("index", -1) ?: -1
        val list  = ScheduleRepo.getAll(requireContext())
        val existing = if (index >= 0 && index < list.size) list[index] else null

        view.announceForAccessibility(if (existing == null) "Yangi vaqt oralig'i" else "Vaqtni tahrirlash")

        val edStart = view.findViewById<EditText>(R.id.edStart)
        val edStop  = view.findViewById<EditText>(R.id.edStop)
        val rgMode  = view.findViewById<RadioGroup>(R.id.rgMode)
        val checkboxContainer = view.findViewById<LinearLayout>(R.id.checkboxContainer)

        // Kunlar checkboxlari
        val checkBoxes = ScheduleRepo.DAY_LABELS.mapIndexed { i, label ->
            CheckBox(requireContext()).apply {
                text = label
                tag  = ScheduleRepo.DAY_VALUES[i]
                isChecked = existing?.days?.contains(ScheduleRepo.DAY_VALUES[i]) ?: false
                checkboxContainer.addView(this)
            }
        }

        // Mavjud qiymatlarni to'ldirish
        existing?.let {
            edStart.setText(it.start)
            edStop.setText(it.stop)
            if (it.mode == "voice") rgMode.check(R.id.rbVoice) else rgMode.check(R.id.rbVisual)
        }

        // Vaqt avtomatik formatlash
        attachTimeFormat(edStart)
        attachTimeFormat(edStop)

        view.findViewById<Button>(R.id.btnSaveSchedule).setOnClickListener {
            val rawS = edStart.text.toString().replace(Regex("[^\\d]"), "")
            val rawE = edStop.text.toString().replace(Regex("[^\\d]"), "")
            if (rawS.length != 4 || rawE.length != 4) {
                Toast.makeText(requireContext(), "Vaqt to'liq kiritilmadi", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            val h1 = rawS.substring(0,2).toInt(); val m1 = rawS.substring(2).toInt()
            val h2 = rawE.substring(0,2).toInt(); val m2 = rawE.substring(2).toInt()
            if (h1 > 23 || h2 > 23 || m1 > 59 || m2 > 59) {
                Toast.makeText(requireContext(), "Vaqt noto'g'ri kiritildi", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            val startStr = "%02d:%02d".format(h1, m1)
            val stopStr  = "%02d:%02d".format(h2, m2)
            if (startStr == stopStr) {
                Toast.makeText(requireContext(), "Boshlanish va tugash vaqti bir xil bo'lishi mumkin emas", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            val newMode = if (rgMode.checkedRadioButtonId == R.id.rbVoice) "voice" else "visual"
            val days = checkBoxes.filter { it.isChecked }.map { it.tag as Int }.takeIf { it.isNotEmpty() }

            // To'qnashuv tekshiruvi
            val startMin = h1*60+m1; val stopMin = h2*60+m2
            val otherMode = if (newMode == "voice") "visual" else "voice"
            val conflict = list.filter { it.mode == otherMode }.firstOrNull { rec ->
                val rs = timeMin(rec.start); val re = timeMin(rec.stop)
                ScheduleRepo.daysOverlap(days, rec.days) && ScheduleRepo.timesOverlap(startMin, stopMin, rs, re)
            }

            fun doSave() {
                val updated = list.toMutableList()
                if (index >= 0) updated.removeAt(index)
                updated.add(ScheduleEntry(startStr, stopStr, days, newMode))
                ScheduleRepo.saveAll(requireContext(), updated)
                Toast.makeText(requireContext(), "Saqlandi", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }

            if (conflict != null) {
                val otherLabel = if (newMode == "voice") "Vizual" else "Ovozli"
                AlertDialog.Builder(requireContext())
                    .setTitle("Diqqat: to'qnashuv")
                    .setMessage("Bu vaqt $otherLabel rejimning ${conflict.start}–${conflict.stop} bilan to'qnashadi. Baribir saqlansinmi?")
                    .setPositiveButton("Ha, saqlash") { _, _ -> doSave() }
                    .setNegativeButton("Yo'q", null).show()
            } else doSave()
        }
    }

    private fun timeMin(t: String): Int {
        val p = t.split(":"); return (p[0].toIntOrNull() ?: 0)*60 + (p[1].toIntOrNull() ?: 0)
    }

    private fun attachTimeFormat(ed: EditText) {
        ed.addTextChangedListener(object : TextWatcher {
            var editing = false
            override fun afterTextChanged(s: Editable?) {
                if (editing) return; editing = true
                val raw = s.toString().replace(Regex("[^\\d]"), "").take(4)
                val fmt = if (raw.length > 2) "${raw.substring(0,2)}:${raw.substring(2)}" else raw
                if (s.toString() != fmt) { ed.setText(fmt); ed.setSelection(fmt.length) }
                editing = false
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }
}
