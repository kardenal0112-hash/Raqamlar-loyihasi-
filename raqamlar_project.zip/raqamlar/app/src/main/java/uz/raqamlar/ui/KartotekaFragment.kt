package uz.raqamlar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.data.KartotekaRepo
import uz.raqamlar.utils.TextUtils

class KartotekaFragment : Fragment() {

    companion object {
        fun newInstance(query: String = "") = KartotekaFragment().apply {
            arguments = Bundle().apply { putString("query", query) }
        }
    }

    private lateinit var listView: ListView
    private lateinit var searchEdit: EditText
    private var allNames = listOf<String>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_kartoteka, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        listView = view.findViewById(R.id.listKartoteka)
        searchEdit = view.findViewById(R.id.searchKartoteka)

        view.findViewById<Button>(R.id.btnYangiIsm).setOnClickListener { showAddDialog() }
        view.findViewById<Button>(R.id.btnZaxiralash).apply {
            setOnClickListener { KartotekaRepo.backup(requireContext()) }
            setOnLongClickListener { restoreFromClipboard(); true }
        }

        loadNames()

        searchEdit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterList(s.toString())
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Agar query bilan kelingan bo'lsa
        arguments?.getString("query")?.let { if (it.isNotEmpty()) searchEdit.setText(it) }

        // TalkBack uchun sarlavha e'lon qilish
        view.announceForAccessibility("Kartoteka")
    }

    private fun loadNames() {
        val db = KartotekaRepo.get(requireContext())
        allNames = db.keys.sorted()
        filterList(searchEdit.text.toString())
    }

    private fun filterList(query: String) {
        val db = KartotekaRepo.get(requireContext())
        val filtered = if (query.isEmpty()) allNames else {
            val skel = TextUtils.getSkel(query)
            val cleanNum = query.replace(Regex("[^\\d]"), "")
            allNames.filter { name ->
                (skel.length >= 1 && TextUtils.getSkel(name).contains(skel)) ||
                (cleanNum.isNotEmpty() && db[name]?.any { it.contains(cleanNum) } == true)
            }
        }
        listView.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, filtered)
        listView.setOnItemClickListener { _, _, pos, _ ->
            val name = listView.adapter.getItem(pos) as String
            (activity as MainActivity).navigateTo(PersonCardsFragment.newInstance(name))
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            val name = listView.adapter.getItem(pos) as String
            showNameOptions(name); true
        }
    }

    private fun showAddDialog() {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 32, 48, 32)
        }
        val editName = EditText(requireContext()).apply { hint = "Ismni kiriting..." }
        val editCard = EditText(requireContext()).apply {
            hint = "16 talik karta raqami..."; inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        // Mic tugmasi ism uchun
        val micName = Button(requireContext()).apply {
            text = "🎤"; contentDescription = "Ismni ovozdan kiriting"
            setOnClickListener { startMicForField(editName, "name") }
        }
        val rowName = LinearLayout(requireContext()).apply { orientation = LinearLayout.HORIZONTAL }
        rowName.addView(editName, LinearLayout.LayoutParams(0, -2, 1f))
        rowName.addView(micName)

        editCard.addTextChangedListener(cardFormatter(editCard))
        layout.addView(rowName); layout.addView(editCard)

        AlertDialog.Builder(requireContext()).setTitle("Yangi ma'lumot qo'shish").setView(layout)
            .setPositiveButton("Saqlash", null).setNegativeButton("Bekor qilish", null)
            .create().also { dlg ->
                dlg.show()
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val name = TextUtils.capitalizeFirst(editName.text.toString())
                    val card = editCard.text.toString().replace(Regex("[^\\d]"), "")
                    val db = KartotekaRepo.get(requireContext())
                    when {
                        name.isEmpty() -> toast("Ism kiritilmadi")
                        db.keys.any { it.equals(name, ignoreCase = true) } -> toast("Bu ism avvaldan mavjud")
                        card.length != 16 -> toast("Karta raqami to'liq emas")
                        !TextUtils.isValidLuhn(card) -> toast("Karta raqami noto'g'ri")
                        db.values.any { it.contains(card) } -> toast("Bu karta raqami allaqachon mavjud")
                        else -> {
                            db[name] = mutableListOf(card)
                            KartotekaRepo.save(requireContext(), db)
                            toast("$name saqlandi")
                            dlg.dismiss(); loadNames()
                        }
                    }
                }
            }
    }

    private fun showNameOptions(name: String) {
        val options = arrayOf("Ismni tahrirlash", "O'chirish")
        AlertDialog.Builder(requireContext()).setTitle(name).setItems(options) { _, w ->
            when (w) {
                0 -> {
                    val ed = EditText(requireContext()).apply { setText(name) }
                    AlertDialog.Builder(requireContext()).setTitle("Ismni tahrirlash").setView(ed)
                        .setPositiveButton("Saqlash") { _, _ ->
                            val newName = TextUtils.capitalizeFirst(ed.text.toString())
                            if (newName.isNotEmpty() && !newName.equals(name, ignoreCase = true)) {
                                val db = KartotekaRepo.get(requireContext())
                                db[newName] = db[name] ?: mutableListOf()
                                db.remove(name)
                                KartotekaRepo.save(requireContext(), db)
                                toast("Ism o'zgartirildi"); loadNames()
                            }
                        }.show()
                }
                1 -> {
                    val db = KartotekaRepo.get(requireContext())
                    db.remove(name); KartotekaRepo.save(requireContext(), db)
                    toast("$name o'chirildi"); loadNames()
                }
            }
        }.show()
    }

    private fun restoreFromClipboard() {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        if (KartotekaRepo.restore(requireContext(), text)) {
            toast("Muvaffaqiyatli tiklandi"); loadNames()
        } else toast("Yaroqli nusxa topilmadi")
    }

    private fun startMicForField(editText: EditText, fieldType: String) {
        val vm = uz.raqamlar.voice.VoiceManager(requireContext())
        vm.startListening(object : uz.raqamlar.voice.VoiceManager.Listener {
            override fun onResult(spoken: String) {
                editText.setText(when (fieldType) {
                    "name" -> TextUtils.capitalizeFirst(spoken)
                    "digits" -> spoken.replace(Regex("[^\\d]"), "")
                    else -> spoken
                })
            }
            override fun onError(code: Int) { toast("Eshitilmadi") }
        })
    }

    private fun cardFormatter(editText: EditText) = object : TextWatcher {
        var editing = false
        override fun afterTextChanged(s: Editable?) {
            if (editing) return
            editing = true
            val raw = s.toString().replace(Regex("[^\\d]"), "").take(16)
            val formatted = raw.chunked(4).joinToString("-")
            if (s.toString() != formatted) { editText.setText(formatted); editText.setSelection(formatted.length) }
            editing = false
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    private fun toast(msg: String) = Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
}
