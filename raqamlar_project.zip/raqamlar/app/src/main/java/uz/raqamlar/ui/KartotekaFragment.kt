package uz.raqamlar.ui

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.data.KartotekaRepo
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.TextUtils

class KartotekaFragment : Fragment() {

    companion object {
        fun newInstance(query: String = "") = KartotekaFragment().apply {
            arguments = Bundle().apply { putString("query", query) }
        }
    }

    private lateinit var listView: ListView
    private lateinit var searchEdit: EditText
    private var allNames = listOf<String>()

    private val act: MainActivity get() = activity as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_kartoteka, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        listView = view.findViewById(R.id.listKartoteka)
        searchEdit = view.findViewById(R.id.searchKartoteka)

        view.findViewById<Button>(R.id.btnYangiIsm).setOnClickListener { showAddDialog() }
        val btnBackup = view.findViewById<Button>(R.id.btnZaxiralash)
        btnBackup.setOnClickListener { KartotekaRepo.backup(requireContext()) }
        btnBackup.setOnLongClickListener { restoreFromClipboard(); true }

        loadNames()

        searchEdit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filterList(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        arguments?.getString("query")?.let { if (it.isNotEmpty()) searchEdit.setText(it) }

        view.announceForAccessibility("Kartoteka")
    }

    private fun loadNames() {
        val db = KartotekaRepo.get(requireContext())
        allNames = db.keys.sorted()
        filterList(searchEdit.text.toString())
    }

    private fun filterList(query: String) {
        val db = KartotekaRepo.get(requireContext())
        val filtered = if (query.isEmpty()) allNames else {
            val skel = TextUtils.getSkel(query)
            val cleanNum = query.replace(Regex("[^\\d]"), "")
            allNames.filter { name ->
                (skel.isNotEmpty() && TextUtils.getSkel(name).contains(skel)) ||
                (cleanNum.isNotEmpty() && db[name]?.any { it.contains(cleanNum) } == true)
            }
        }
        listView.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, filtered)
        listView.setOnItemClickListener { _, _, pos, _ ->
            val name = listView.adapter.getItem(pos) as String
            act.navigateTo(PersonCardsFragment.newInstance(name))
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            val name = listView.adapter.getItem(pos) as String
            showNameOptions(name)
            true
        }
    }

    private fun showAddDialog() {
        val layout = LinearLayout(requireContext())
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(48, 32, 48, 32)
        val editName = EditText(requireContext())
        editName.hint = "Ismni kiriting..."
        val editCard = EditText(requireContext())
        editCard.hint = "16 talik karta raqami..."
        editCard.inputType = InputType.TYPE_CLASS_NUMBER
        editCard.addTextChangedListener(cardFormatter(editCard))
        layout.addView(editName)
        layout.addView(editCard)

        val dlg = Flows.hook(
            AlertDialog.Builder(requireContext()).setTitle("Yangi ma'lumot qo'shish").setView(layout)
                .setPositiveButton("Saqlash", null).setNegativeButton("Bekor qilish", null).create(),
            act
        )
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val name = TextUtils.capitalizeAll(editName.text.toString())
            val card = editCard.text.toString().replace(Regex("[^\\d]"), "")
            val db = KartotekaRepo.get(requireContext())
            when {
                name.isEmpty() -> toast("Ism kiritilmadi")
                db.keys.any { it.equals(name, ignoreCase = true) } -> toast("Bu ism avvaldan mavjud")
                card.length != 16 -> toast("Karta raqami to'liq emas")
                !TextUtils.isValidLuhn(card) -> toast("Karta raqami noto'g'ri")
                db.values.any { it.contains(card) } -> toast("Bu karta raqami allaqachon mavjud")
                else -> {
                    db[name] = mutableListOf(card)
                    KartotekaRepo.save(requireContext(), db)
                    toast("$name saqlandi")
                    dlg.dismiss()
                    loadNames()
                }
            }
        }
    }

    private fun showNameOptions(name: String) {
        val options = arrayOf("Tahrirlash", "O'chirish")
        val b = AlertDialog.Builder(requireContext()).setTitle(name).setItems(options) { _, w ->
            if (w == 0) {
                val ed = EditText(requireContext())
                ed.hint = "Ismni tahrirlash..."
                ed.setText(name)
                val b2 = AlertDialog.Builder(requireContext()).setTitle("Ismni tahrirlash").setView(ed)
                    .setPositiveButton("Saqlash") { _, _ ->
                        val newName = TextUtils.capitalizeAll(ed.text.toString())
                        val db = KartotekaRepo.get(requireContext())
                        if (newName.isNotEmpty() && newName != name) {
                            if (db.keys.any { it.equals(newName, ignoreCase = true) && it != name }) {
                                toast("Bu ism bazada bor")
                            } else {
                                db[newName] = db[name] ?: mutableListOf()
                                db.remove(name)
                                KartotekaRepo.save(requireContext(), db)
                                toast("Ism o'zgartirildi")
                                loadNames()
                            }
                        }
                    }
                Flows.show(act, b2)
            } else {
                val b3 = AlertDialog.Builder(requireContext()).setTitle("O'chirish")
                    .setMessage("$name va uning barcha kartalarini o'chirishni tasdiqlaysizmi?")
                    .setPositiveButton("Ha, o'chirish") { _, _ ->
                        val db = KartotekaRepo.get(requireContext())
                        db.remove(name)
                        KartotekaRepo.save(requireContext(), db)
                        toast("$name o'chirildi")
                        loadNames()
                    }
                    .setNegativeButton("Bekor qilish", null)
                Flows.show(act, b3)
            }
        }
        Flows.show(act, b)
    }

    private fun restoreFromClipboard() {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        if (clip == null || clip.itemCount == 0) {
            toast("Bufer bo'sh")
            return
        }
        val text = clip.getItemAt(0).text?.toString() ?: ""
        if (KartotekaRepo.restore(requireContext(), text)) {
            toast("Muvaffaqiyatli tiklandi")
            loadNames()
        } else {
            toast("Yaroqli nusxa topilmadi")
        }
    }

    private fun cardFormatter(editText: EditText) = object : TextWatcher {
        var editing = false
        override fun afterTextChanged(s: Editable?) {
            if (editing) return
            editing = true
            val raw = s.toString().replace(Regex("[^\\d]"), "").take(16)
            val formatted = raw.chunked(4).joinToString("-")
            if (s.toString() != formatted) {
                editText.setText(formatted)
                editText.setSelection(formatted.length)
            }
            editing = false
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    private fun toast(msg: String) = Say.show(requireContext(), msg)
}
