package uz.raqamlar.voice

import androidx.appcompat.app.AlertDialog
import uz.raqamlar.MainActivity
import uz.raqamlar.data.KartotekaRepo
import uz.raqamlar.ui.CallLogFragment
import uz.raqamlar.ui.Flows
import uz.raqamlar.ui.KartotekaFragment
import uz.raqamlar.ui.PersonCardsFragment
import uz.raqamlar.ui.UniversalSearchFragment
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.TextUtils

// Ovozli buyruqlarni qayta ishlash (plagindagi tartibga mos)
object VoiceCommands {

    private const val NEED_SERVICE =
        "Bu buyruq ekran matnini o'qishni talab qiladi. U keyingi yangilanishda qo'shiladi."

    private fun callTitle(kind: String): String = when (kind) {
        "kiruvchi" -> "Kiruvchi qo'ng'iroqlar"
        "chiquvchi" -> "Chiquvchi qo'ng'iroqlar"
        "berilmagan" -> "Javobsiz qo'ng'iroqlar"
        else -> "Oxirgi qo'ng'iroqlar"
    }

    fun handle(act: MainActivity, original: String) {
        val spoken = original.lowercase().trim()
        val commandCheck = spoken.replace(" ", "")

        if (commandCheck == "telefon" || commandCheck == "nomer" || commandCheck == "karta") {
            Say.show(act, NEED_SERVICE, true)
            return
        }

        var action = "telefon"
        var query = spoken

        if (commandCheck.contains("video")) {
            action = "video"
            query = spoken
            for (w in listOf("video", "qo'ng'iroq", "qongiroq", "chaqiruv", "chaqiru")) {
                query = query.replace(w, "")
            }
            query = query.trim()
        } else {
            val actionMap = linkedMapOf(
                "nusxalash" to "nusxalash", "saqlash" to "saqlash", "telegram" to "telegram",
                "whatsapp" to "whatsapp", "xabar" to "xabar", "to'lov" to "to'lov", "tolov" to "to'lov",
                "chaqirish" to "chaqirish", "chaqiruv" to "chaqirish", "chaqiru" to "chaqirish",
                "iroq" to "chaqirish", "vizav" to "chaqirish", "tkaz" to "o'tkazma"
            )
            for ((key, v) in actionMap) {
                if (spoken.contains(key)) {
                    action = v
                    query = spoken.replace(key, "").trim()
                    break
                }
            }
        }

        if (commandCheck.contains("oddiyrejim")) {
            Say.show(act, "Oddiy rejim yoqildi")
            return
        }

        if (commandCheck.contains("tezkor")) {
            Say.show(act, NEED_SERVICE, true)
            return
        }

        if (commandCheck.contains("qidirish") || commandCheck.contains("kidirish")) {
            act.navigateTo(UniversalSearchFragment())
            return
        }

        // Qo'ng'iroqlar jurnali buyruqlari
        val callKind: String? = when {
            spoken.contains("kiruvchi") || spoken.contains("kiruchi") -> "kiruvchi"
            spoken.contains("chiquvchi") || spoken.contains("chiquchi") -> "chiquvchi"
            spoken.contains("javob berilmagan") || commandCheck.contains("javobberilmagan") ||
                spoken.contains("javobsiz") || spoken.contains("berilmagan") || spoken.contains("otkazib") -> "berilmagan"
            spoken.contains("oxirgi") -> "oxirgi"
            else -> null
        }
        if (callKind != null) {
            val logType: String? = if (callKind != "oxirgi") callKind else null
            val wantList = commandCheck.contains("royxat") || commandCheck.contains("ro'yxat") || commandCheck.contains("roiyxat")
            if (wantList) {
                act.navigateTo(CallLogFragment.newInstance(logType, callTitle(callKind)))
                return
            }
            if (spoken.contains("to'lov") || spoken.contains("tolov") || spoken.contains("o'tkazma")) {
                val entry = ContactUtils.getCallLogEntry(act, logType)
                if (entry != null) Flows.showSummaDialog(act, entry.num) else Say.show(act, "Qo'ng'iroq topilmadi")
                return
            }
            val callAction = when {
                spoken.contains("telegram") -> "telegram"
                spoken.contains("whatsapp") -> "whatsapp"
                spoken.contains("nusxalash") -> "nusxalash"
                spoken.contains("xabar") -> "xabar"
                spoken.contains("video") -> "video"
                spoken.contains("saqlash") -> "saqlash"
                else -> "telefon"
            }
            val entry = ContactUtils.getCallLogEntry(act, logType)
            if (entry == null) {
                Say.show(act, "Qo'ng'iroq topilmadi")
            } else {
                Flows.executePhoneCommand(act, callAction, entry.num)
            }
            return
        }

        val hasKarta = commandCheck.contains("karta")
        val hasKartoteka = commandCheck.contains("kartoteka")

        if (hasKarta && !hasKartoteka && (action == "o'tkazma" || action == "saqlash" || action == "nusxalash")) {
            Say.show(act, NEED_SERVICE, true)
            return
        }

        if ((commandCheck.contains("telefon") || commandCheck.contains("nomer")) && !hasKarta) {
            Say.show(act, NEED_SERVICE, true)
            return
        }

        // Kontakt bo'yicha qidirish
        if (query.isNotEmpty() && !hasKarta) {
            val results = ContactUtils.searchContactsVoice(act, query)
            when {
                results.isEmpty() -> Say.show(act, "$query topilmadi")
                results.size == 1 -> Flows.executePhoneCommand(act, action, results[0].num)
                else -> {
                    val items = ArrayList<String>()
                    for (r in results) items.add(r.display)
                    val b = AlertDialog.Builder(act).setTitle("Qidiruv natijalari")
                    val dlg = Flows.hook(b.setItems(items.toTypedArray()) { d, pos ->
                        d.dismiss()
                        Flows.executePhoneCommand(act, action, results[pos].num)
                    }.create(), act)
                    dlg.show()
                    dlg.listView.setOnItemLongClickListener { _, _, pos, _ ->
                        dlg.dismiss()
                        Flows.showFinalActions(act, results[pos].num, false, "Raqam")
                        true
                    }
                }
            }
            return
        }

        // Kartoteka bo'yicha qidirish
        if (hasKartoteka) {
            val q = spoken.replace("kartoteka", "").trim()
            if (q.isEmpty()) {
                act.navigateTo(KartotekaFragment())
                return
            }
            val db = KartotekaRepo.get(act)
            val skelQ = TextUtils.getSkel(q)
            val cleanQ = q.replace(Regex("[^\\d]"), "")
            val found = ArrayList<String>()
            for ((name, cards) in db) {
                var match = skelQ.length >= 2 && TextUtils.getSkel(name).contains(skelQ)
                if (!match && cleanQ.length >= 4) {
                    match = cards.any { it.replace(Regex("[^\\d]"), "").contains(cleanQ) }
                }
                if (match) found.add(name)
            }
            found.sort()
            when {
                found.isEmpty() -> Say.show(act, "$q topilmadi")
                found.size == 1 -> act.navigateTo(PersonCardsFragment.newInstance(found[0]))
                else -> {
                    val b = AlertDialog.Builder(act).setTitle("Natijalar")
                        .setItems(found.toTypedArray()) { d, pos ->
                            d.dismiss()
                            act.navigateTo(PersonCardsFragment.newInstance(found[pos]))
                        }
                    Flows.show(act, b)
                }
            }
            return
        }

        if (action != "telefon" || commandCheck.contains("nusxalash")) {
            Say.show(act, NEED_SERVICE, true)
            return
        }

        Say.show(act, "Tushunarsiz buyruq")
    }
}
