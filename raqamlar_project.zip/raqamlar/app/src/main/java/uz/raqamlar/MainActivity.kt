package uz.raqamlar

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import uz.raqamlar.ui.MainFragment
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.VolumeKeyHandler
import uz.raqamlar.voice.Dictation
import uz.raqamlar.voice.VoiceCommands
import uz.raqamlar.voice.VoiceManager

class MainActivity : AppCompatActivity() {

    companion object {
        const val REQ_PERMISSIONS = 100
        val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.RECORD_AUDIO
        )
    }

    val voice: VoiceManager by lazy { VoiceManager(this) }
    private var voiceRetries = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            checkPermissionsAndStart()
        }
    }

    private fun checkPermissionsAndStart() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        } else {
            startApp()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (supportFragmentManager.findFragmentById(R.id.fragment_container) == null) {
            startApp()
        }
    }

    private fun startApp() {
        navigateTo(MainFragment(), addToBackStack = false)
    }

    fun navigateTo(fragment: Fragment, addToBackStack: Boolean = true) {
        val tx = supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
        if (addToBackStack) tx.addToBackStack(null)
        tx.commit()
    }

    // ---------- ovozli buyruq (plagindagidek: bir marta tinglaydi, xatoda 3 martagacha qayta uriniladi) ----------

    fun startVoiceCommand() {
        voiceRetries = 0
        listenCommand()
    }

    private fun listenCommand() {
        if (!voice.isNetworkAvailable()) {
            voiceRetries = 0
            Say.show(this, "Internet aloqasi yo'q", true)
            return
        }
        voice.startListening(object : VoiceManager.Listener {
            override fun onResult(spoken: String) {
                voiceRetries = 0
                VoiceCommands.handle(this@MainActivity, spoken)
            }

            override fun onError(code: Int) {
                if (code == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                    code == SpeechRecognizer.ERROR_NETWORK ||
                    !voice.isNetworkAvailable()
                ) {
                    voiceRetries = 0
                    Say.show(this@MainActivity, "Internet aloqasi yo'q", true)
                    return
                }
                voiceRetries++
                if (voiceRetries >= 3) {
                    voiceRetries = 0
                    Say.show(this@MainActivity, "Eshitish to'xtatildi.")
                } else {
                    val msg = if (code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                        "Sizni eshitolmadim, qaytadan ayting" else "Tushunarsiz buyruq, takrorlang"
                    Say.show(this@MainActivity, msg)
                    handler.postDelayed({
                        if (!isFinishing && !isDestroyed) listenCommand()
                    }, 1500)
                }
            }
        })
    }

    // ---------- ovozni kamaytirish tugmasini uzoq bosish ----------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (VolumeKeyHandler.handle(this, event, window.decorView)) return true
        return super.dispatchKeyEvent(event)
    }

    fun onVolumeDownLongPress(root: View?) {
        val r = root ?: window.decorView
        val edit = Dictation.findEdit(r)
        if (edit != null) Dictation.start(this, edit) else startVoiceCommand()
    }

    override fun onBackPressed() {
        if (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        voice.destroy()
    }
}
