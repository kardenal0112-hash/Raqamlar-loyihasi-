package uz.raqamlar.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

object KartotekaRepo {
    private const val PREFS = "kartateka_data"
    private const val KEY   = "data_json"
    private const val SIG   = "KARTATEKA_SAFE_V1"

    // Map<ism, List<kartaRaqami>>
    fun get(ctx: Context): MutableMap<String, MutableList<String>> {
        val json = ctx.getSharedPreferences(PREFS, 0).getString(KEY, "{}") ?: "{}"
        val result = mutableMapOf<String, MutableList<String>>()
        return try {
            val obj = JSONObject(json)
            for (key in obj.keys()) {
                val arr = obj.getJSONArray(key)
                val cards = mutableListOf<String>()
                for (i in 0 until arr.length()) cards.add(arr.getString(i))
                result[key] = cards
            }
            result
        } catch (e: Exception) { result }
    }

    fun save(ctx: Context, data: Map<String, List<String>>) {
        val obj = JSONObject()
        data.keys.sorted().forEach { name ->
            val arr = org.json.JSONArray()
            data[name]?.forEach { arr.put(it) }
            obj.put(name, arr)
        }
        ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, obj.toString()).apply()
    }

    fun backup(ctx: Context) {
        val raw = ctx.getSharedPreferences(PREFS, 0).getString(KEY, "{}") ?: "{}"
        val content = "$SIG\n$raw"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, content)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        ctx.startActivity(Intent.createChooser(intent, "Kartotekani zaxiralash")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun restore(ctx: Context, clipText: String): Boolean {
        if (!clipText.contains(SIG)) return false
        val pure = Regex("\\{.+\\}", RegexOption.DOT_MATCHES_ALL).find(clipText)?.value ?: return false
        return try {
            JSONObject(pure) // validatsiya
            ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, pure).apply()
            true
        } catch (e: Exception) { false }
    }
}
