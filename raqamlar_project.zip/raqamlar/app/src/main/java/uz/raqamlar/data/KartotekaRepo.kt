package uz.raqamlar.data

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

object KartotekaRepo {
    private const val PREFS = "kartateka_data"
    private const val KEY   = "data_json"
    private const val SIG   = "KARTATEKA_SAFE_V1"

    // Map<ism, List<kartaRaqami>>
    fun get(ctx: Context): MutableMap<String, MutableList<String>> {
        val json = ctx.getSharedPreferences(PREFS, 0).getString(KEY, "{}") ?: "{}"
        return parseJson(json) ?: mutableMapOf()
    }

    fun save(ctx: Context, data: Map<String, List<String>>) {
        val obj = JSONObject()
        data.keys.sorted().forEach { name ->
            val arr = JSONArray()
            data[name]?.forEach { arr.put(it) }
            obj.put(name, arr)
        }
        ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, obj.toString()).apply()
    }

    // Zaxira nusxa plagin formatida (Lua jadvali) yoziladi, shuning uchun plagin ham o'qiy oladi
    fun backup(ctx: Context) {
        val content = SIG + "\n" + toLua(get(ctx))
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, content)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        ctx.startActivity(Intent.createChooser(intent, "Kartotekani zaxiralash")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // Plagin formati (Lua jadvali) ham, ilovaning eski JSON formati ham qabul qilinadi
    fun restore(ctx: Context, clipText: String): Boolean {
        val sigPos = clipText.indexOf(SIG)
        if (sigPos < 0) return false
        val start = clipText.indexOf('{', sigPos)
        val end = clipText.lastIndexOf('}')
        if (start < 0 || end <= start) return false
        val pure = clipText.substring(start, end + 1)
        val parsed = parseLua(pure) ?: parseJson(pure) ?: return false
        save(ctx, parsed)
        return true
    }

    private fun parseJson(json: String): MutableMap<String, MutableList<String>>? {
        return try {
            val result = mutableMapOf<String, MutableList<String>>()
            val obj = JSONObject(json)
            for (key in obj.keys()) {
                val arr = obj.getJSONArray(key)
                val cards = mutableListOf<String>()
                for (i in 0 until arr.length()) cards.add(arr.getString(i))
                result[key] = cards
            }
            result
        } catch (e: Exception) {
            null
        }
    }

    private fun luaQuote(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\\n")
                '\r' -> sb.append("\\r")
                else -> sb.append(c)
            }
        }
        sb.append('"')
        return sb.toString()
    }

    private fun toLua(data: Map<String, List<String>>): String {
        val sb = StringBuilder("{")
        for (name in data.keys.sorted()) {
            sb.append("[").append(luaQuote(name)).append("]={")
            data[name]?.forEach { sb.append(luaQuote(it)).append(",") }
            sb.append("},")
        }
        sb.append("}")
        return sb.toString()
    }

    // {["Ism"]={"8600...","9860...",},["Ism2"]={...},} ko'rinishidagi jadvalni o'qiydi
    private fun parseLua(s: String): MutableMap<String, MutableList<String>>? {
        val n = s.length
        var i = 0

        fun skipWs() {
            while (i < n && s[i].isWhitespace()) i++
        }

        fun readString(): String? {
            if (i >= n || s[i] != '"') return null
            i++
            val sb = StringBuilder()
            while (i < n && s[i] != '"') {
                if (s[i] == '\\' && i + 1 < n) {
                    i++
                    when (s[i]) {
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        else -> sb.append(s[i])
                    }
                } else {
                    sb.append(s[i])
                }
                i++
            }
            if (i >= n) return null
            i++
            return sb.toString()
        }

        skipWs()
        if (i >= n || s[i] != '{') return null
        i++
        val result = mutableMapOf<String, MutableList<String>>()
        while (true) {
            skipWs()
            if (i >= n) return null
            if (s[i] == '}') { i++; break }
            if (s[i] == ',') { i++; continue }
            if (s[i] != '[') return null
            i++
            skipWs()
            val name = readString() ?: return null
            skipWs()
            if (i >= n || s[i] != ']') return null
            i++
            skipWs()
            if (i >= n || s[i] != '=') return null
            i++
            skipWs()
            if (i >= n || s[i] != '{') return null
            i++
            val cards = mutableListOf<String>()
            while (true) {
                skipWs()
                if (i >= n) return null
                if (s[i] == '}') { i++; break }
                if (s[i] == ',') { i++; continue }
                val c = readString() ?: return null
                cards.add(c)
            }
            result[name] = cards
        }
        return result
    }
}
