package uz.raqamlar.ui

import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.data.KartotekaRepo
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.TextUtils

class PersonCardsFragment : Fragment() {

    companion object {
        fun newInstance(name: String) = PersonCardsFragment().apply {
            arguments = Bundle().apply { putString("name", name) }
        }
    }

    private val name: String get() = arguments?.getString("name") ?: ""
    private val act: MainActivity get() = activity as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_person_cards, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility(name)
        loadCards(view)
        view.findViewById<Button>(R.id.btnKartaQoshish).setOnClickListener { showAddCardDialog() }
    }

    private fun loadCards(view: View) {
        val db = KartotekaRepo.get(requireContext())
        val cards: List<String> = db[name] ?: emptyList()
        val list = ArrayList<String>()
        for (c in cards) list.add(TextUtils.getBankName(c) + ": " + TextUtils.formatCardForVoice(c))
        list.add("Karta qo'shish")
        val lv = view.findViewById<ListView>(R.id.listCards)
        lv.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, list)
        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos < cards.size) Flows.showSummaDialog(act, cards[pos]) else showAddCardDialog()
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < cards.size) {
                showCardOptions(cards[pos], pos)
                true
            } else {
                false
            }
        }
    }

    private fun showCardOptions(cardNum: String, idx: Int) {
        val options = arrayOf("Nusxalash", "Tahrirlash", "O'chirish")
        val b = AlertDialog.Builder(requireContext()).setTitle("Amalni tanlang").setItems(options) { _, w ->
            when (w) {
                0 -> {
                    Flows.copy(requireContext(), cardNum)
                    Say.show(requireContext(), "Nusxalandi")
                }
                1 -> showEditCardDialog(cardNum, idx)
                2 -> {
                    val b3 = AlertDialog.Builder(requireContext()).setTitle("O'chirish")
                        .setMessage(TextUtils.getBankName(cardNum) + " kartasini o'chirishni tasdiqlaysizmi?")
                        .setPositiveButton("Ha, o'chirish") { _, _ ->
                            val db = KartotekaRepo.get(requireContext())
                            db[name]?.removeAt(idx)
                            KartotekaRepo.save(requireContext(), db)
                            Say.show(requireContext(), "O'chirildi")
                            view?.let { loadCards(it) }
                        }
                        .setNegativeButton("Bekor qilish", null)
                    Flows.show(act, b3)
                }
            }
        }
        Flows.show(act, b)
    }

    private fun showEditCardDialog(cardNum: String, idx: Int) {
        val ed = EditText(requireContext())
        ed.inputType = InputType.TYPE_CLASS_NUMBER
        ed.hint = "Kartani tahrirlash..."
        ed.setText(cardNum)
        val b = AlertDialog.Builder(requireContext()).setTitle("Kartani tahrirlash").setView(ed)
            .setPositiveButton("Saqlash") { _, _ ->
                val updated = ed.text.toString().replace(Regex("[^\\d]"), "")
                if (updated.length == 16) {
                    if (!TextUtils.isValidLuhn(updated)) {
                        Say.show(requireContext(), "karta raqami noto'g'ri kiritildi")
                    } else {
                        val db = KartotekaRepo.get(requireContext())
                        db[name]?.set(idx, updated)
                        KartotekaRepo.save(requireContext(), db)
                        Say.show(requireContext(), "O'zgartirildi")
                        view?.let { loadCards(it) }
                    }
                } else {
                    Say.show(requireContext(), "karta raqami noto'g'ri kiritildi")
                }
            }
        Flows.show(act, b)
    }

    private fun showAddCardDialog() {
        val editCard = EditText(requireContext())
        editCard.hint = "16 talik karta raqami..."
        editCard.inputType = InputType.TYPE_CLASS_NUMBER
        editCard.addTextChangedListener(object : TextWatcher {
            var editing = false
            override fun afterTextChanged(s: Editable?) {
                if (editing) return
                editing = true
                val raw = s.toString().replace(Regex("[^\\d]"), "").take(16)
                val fmt = raw.chunked(4).joinToString("-")
                if (s.toString() != fmt) {
                    editCard.setText(fmt)
                    editCard.setSelection(fmt.length)
                }
                editing = false
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        val dlg = Flows.hook(
            AlertDialog.Builder(requireContext()).setTitle("$name: Karta qo'shish").setView(editCard)
                .setPositiveButton("Saqlash", null).setNegativeButton("Bekor qilish", null).create(),
            act
        )
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val card = editCard.text.toString().replace(Regex("[^\\d]"), "")
            val db = KartotekaRepo.get(requireContext())
            when {
                card.length != 16 -> Say.show(requireContext(), "Karta raqami to'liq emas")
                !TextUtils.isValidLuhn(card) -> Say.show(requireContext(), "Karta raqami noto'g'ri")
                db.values.any { it.contains(card) } -> Say.show(requireContext(), "Bu karta allaqachon mavjud")
                else -> {
                    db.getOrPut(name) { mutableListOf() }.add(card)
                    KartotekaRepo.save(requireContext(), db)
                    Say.show(requireContext(), "Qo'shildi")
                    dlg.dismiss()
                    view?.let { loadCards(it) }
                }
            }
        }
    }
}
