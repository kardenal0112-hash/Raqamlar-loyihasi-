package uz.raqamlar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.R
import uz.raqamlar.data.KartotekaRepo
import uz.raqamlar.utils.PrefsHelper
import uz.raqamlar.utils.TextUtils

class PersonCardsFragment : Fragment() {

    companion object {
        fun newInstance(name: String) = PersonCardsFragment().apply {
            arguments = Bundle().apply { putString("name", name) }
        }
    }

    private val name get() = arguments?.getString("name") ?: ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_person_cards, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility(name)
        loadCards(view)
        view.findViewById<Button>(R.id.btnKartaQoshish).setOnClickListener { showAddCardDialog() }
    }

    private fun loadCards(view: View) {
        val db = KartotekaRepo.get(requireContext())
        val cards = db[name] ?: emptyList()
        val list = cards.map { "${TextUtils.getBankName(it)}: ${TextUtils.formatCardForVoice(it)}" } +
                   listOf("+ Karta qo'shish (menyu orqali)")
        val lv = view.findViewById<ListView>(R.id.listCards)
        lv.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, list)
        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos < cards.size) showCardActions(cards[pos], pos)
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < cards.size) { showCardDelete(cards[pos], pos); true } else false
        }
    }

    private fun showCardActions(cardNum: String, idx: Int) {
        val options = arrayOf("Nusxalab olish", "To'lov / O'tkazma", "O'chirish")
        AlertDialog.Builder(requireContext())
            .setTitle("${TextUtils.getBankName(cardNum)}: ${TextUtils.formatCardForVoice(cardNum)}")
            .setItems(options) { _, w ->
                when (w) {
                    0 -> {
                        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("l", cardNum))
                        Toast.makeText(requireContext(), "Nusxalandi", Toast.LENGTH_SHORT).show()
                    }
                    1 -> showBankPicker(cardNum)
                    2 -> showCardDelete(cardNum, idx)
                }
            }.show()
    }

    private fun showCardDelete(cardNum: String, idx: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("O'chirish")
            .setMessage("${TextUtils.getBankName(cardNum)} kartasini o'chirishni tasdiqlaysizmi?")
            .setPositiveButton("Ha, o'chirish") { _, _ ->
                val db = KartotekaRepo.get(requireContext())
                db[name]?.removeAt(idx)
                KartotekaRepo.save(requireContext(), db)
                Toast.makeText(requireContext(), "O'chirildi", Toast.LENGTH_SHORT).show()
                view?.let { loadCards(it) }
            }
            .setNegativeButton("Bekor qilish", null).show()
    }

    private fun showBankPicker(cardNum: String) {
        val pm = requireContext().packageManager
        val finKeys = listOf("click","payme","uzum","paynet","tbc","zoomrad","milliy","hamkor",
            "kapital","ipakyuli","agro","sqb","anor","uzcard","humo","alif","quant","nasiya","soliq","poytaxt")
        val names = mutableListOf<String>()
        val pkgs  = mutableListOf<String>()
        pm.getInstalledApplications(0).forEach { info ->
            val pkg   = info.packageName.lowercase()
            val label = pm.getApplicationLabel(info).toString()
            val fin   = finKeys.any { pkg.contains(it) || label.lowercase().contains(it) }
            if ((fin || pkg.contains("bank") || pkg.contains("pay") || PrefsHelper.isForceAdded(requireContext(), info.packageName))
                && !PrefsHelper.isHidden(requireContext(), info.packageName)
                && pm.getLaunchIntentForPackage(info.packageName) != null) {
                names.add(label); pkgs.add(info.packageName)
            }
        }
        if (names.isEmpty()) { Toast.makeText(requireContext(), "Bank ilovasi topilmadi", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(requireContext()).setTitle("Ilovani tanlang")
            .setItems(names.toTypedArray()) { _, w ->
                // Karta raqamini clipboard'ga nusxalash + bank ilovasini ochish
                val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("l", cardNum))
                Toast.makeText(requireContext(),
                    "Karta raqami nusxalandi. Kerakli maydonga uzoq bosib joylang.",
                    Toast.LENGTH_LONG).show()
                pm.getLaunchIntentForPackage(pkgs[w])?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }?.let { startActivity(it) }
            }.show()
    }

    private fun showAddCardDialog() {
        val editCard = EditText(requireContext()).apply {
            hint = "16 talik karta raqami..."; inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        editCard.addTextChangedListener(object : TextWatcher {
            var editing = false
            override fun afterTextChanged(s: Editable?) {
                if (editing) return; editing = true
                val raw = s.toString().replace(Regex("[^\\d]"), "").take(16)
                val fmt = raw.chunked(4).joinToString("-")
                if (s.toString() != fmt) { editCard.setText(fmt); editCard.setSelection(fmt.length) }
                editing = false
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        AlertDialog.Builder(requireContext()).setTitle("$name: Karta qo'shish").setView(editCard)
            .setPositiveButton("Saqlash", null).setNegativeButton("Bekor qilish", null)
            .create().also { dlg ->
                dlg.show()
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val card = editCard.text.toString().replace(Regex("[^\\d]"), "")
                    val db = KartotekaRepo.get(requireContext())
                    when {
                        card.length != 16 -> Toast.makeText(requireContext(), "Karta raqami to'liq emas", Toast.LENGTH_SHORT).show()
                        !TextUtils.isValidLuhn(card) -> Toast.makeText(requireContext(), "Karta raqami noto'g'ri", Toast.LENGTH_SHORT).show()
                        db.values.any { it.contains(card) } -> Toast.makeText(requireContext(), "Bu karta allaqachon mavjud", Toast.LENGTH_SHORT).show()
                        else -> {
                            db.getOrPut(name) { mutableListOf() }.add(card)
                            KartotekaRepo.save(requireContext(), db)
                            Toast.makeText(requireContext(), "Qo'shildi", Toast.LENGTH_SHORT).show()
                            dlg.dismiss(); view?.let { loadCards(it) }
                        }
                    }
                }
            }
    }
}
