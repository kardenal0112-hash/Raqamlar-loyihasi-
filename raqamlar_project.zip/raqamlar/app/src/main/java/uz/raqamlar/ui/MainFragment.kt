package uz.raqamlar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.PrefsHelper
import uz.raqamlar.utils.TextUtils
import uz.raqamlar.voice.VoiceManager

class MainFragment : Fragment() {

    companion object {
        private const val ARG_VOICE = "start_voice"
        fun newInstance(startInVoice: Boolean) = MainFragment().apply {
            arguments = Bundle().apply { putBoolean(ARG_VOICE, startInVoice) }
        }
    }

    private lateinit var voiceManager: VoiceManager
    private var retryCount = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_main, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext()
        voiceManager = VoiceManager(ctx)

        // Asosiy tugmalar
        view.findViewById<Button>(R.id.btnVoice).apply {
            setOnClickListener { startVoiceOnce() }
            setOnLongClickListener {
                val newState = !PrefsHelper.isVoiceMode(ctx)
                PrefsHelper.setVoiceMode(ctx, newState)
                Toast.makeText(ctx, if (newState) "Doimiy ovozli rejim yoqildi" else "Doimiy ovozli rejim o'chirildi", Toast.LENGTH_SHORT).show()
                if (newState) startVoicePermanent()
                true
            }
        }
        view.findViewById<Button>(R.id.btnSearch).setOnClickListener {
            (activity as MainActivity).navigateTo(UniversalSearchFragment())
        }
        view.findViewById<Button>(R.id.btnKartoteka).setOnClickListener {
            (activity as MainActivity).navigateTo(KartotekaFragment())
        }
        view.findViewById<Button>(R.id.btnWorkMode).setOnClickListener {
            (activity as MainActivity).navigateTo(WorkModeFragment())
        }

        // Qo'ng'iroq tugmalari
        setupCallButton(view, R.id.btnKiruvchi, "kiruvchi")
        setupCallButton(view, R.id.btnChiquvchi, "chiquvchi")
        setupCallButton(view, R.id.btnBerilmagan, "berilmagan")
        setupCallButton(view, R.id.btnOxirgi, null)

        // Agar doimiy ovozli rejim yoki avtomatik boshlash kerak bo'lsa
        if (arguments?.getBoolean(ARG_VOICE) == true) {
            startVoicePermanent()
        }
    }

    private fun setupCallButton(view: View, btnId: Int, callType: String?) {
        view.findViewById<Button>(btnId).apply {
            setOnClickListener { callLastEntry(callType) }
            setOnLongClickListener {
                val title = when (callType) {
                    "kiruvchi" -> "Kiruvchi qo'ng'iroqlar"
                    "chiquvchi" -> "Chiquvchi qo'ng'iroqlar"
                    "berilmagan" -> "Javob berilmagan qo'ng'iroqlar"
                    else -> "Oxirgi qo'ng'iroqlar"
                }
                (activity as MainActivity).navigateTo(CallLogFragment.newInstance(callType, title))
                true
            }
        }
    }

    private fun callLastEntry(callType: String?) {
        val entry = ContactUtils.getCallLogEntry(requireContext(), callType)
        if (entry == null) {
            Toast.makeText(ctx(), "Qo'ng'iroq topilmadi", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${entry.num}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }

    // Bir martalik ovozli buyruq
    private fun startVoiceOnce() {
        if (!voiceManager.isNetworkAvailable()) {
            Toast.makeText(ctx(), "Internet aloqasi yo'q", Toast.LENGTH_SHORT).show(); return
        }
        retryCount = 0
        voiceManager.startListening(object : VoiceManager.Listener {
            override fun onResult(spoken: String) { retryCount = 0; handleCommand(spoken, false) }
            override fun onError(code: Int) {
                if (code == 7) Toast.makeText(ctx(), "Eshitilmadi", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Doimiy ovozli rejim (har buyruqdan keyin qayta tinglaydi)
    private fun startVoicePermanent() {
        if (!voiceManager.isNetworkAvailable()) {
            PrefsHelper.setVoiceMode(ctx(), false)
            Toast.makeText(ctx(), "Internet aloqasi yo'q", Toast.LENGTH_SHORT).show(); return
        }
        voiceManager.startListening(object : VoiceManager.Listener {
            override fun onResult(spoken: String) {
                retryCount = 0
                handleCommand(spoken, true)
            }
            override fun onError(code: Int) {
                if (code == 1 || code == 2) {
                    PrefsHelper.setVoiceMode(ctx(), false)
                    Toast.makeText(ctx(), "Internet yo'q, ovozli rejim o'chirildi", Toast.LENGTH_SHORT).show()
                    return
                }
                retryCount++
                if (retryCount >= 3) {
                    retryCount = 0
                    Toast.makeText(ctx(), "Eshitish to'xtatildi", Toast.LENGTH_SHORT).show()
                } else {
                    if (!isDetached && PrefsHelper.isVoiceMode(ctx())) startVoicePermanent()
                }
            }
        })
    }

    private fun ctx() = requireContext()

    private fun handleCommand(spoken: String, permanent: Boolean) {
        val noSpace = spoken.replace(" ", "")

        // Ovozli rejimni o'chirish
        if (noSpace.contains("oddiyrejim")) {
            PrefsHelper.setVoiceMode(ctx(), false)
            Toast.makeText(ctx(), "Oddiy rejim yoqildi", Toast.LENGTH_SHORT).show()
            return
        }

        // Ish tartibi
        if (noSpace.contains("ishtartibi") || noSpace.contains("jadval") || noSpace.contains("joylashuv")) {
            (activity as MainActivity).navigateTo(WorkModeFragment()); return
        }

        // Qo'ng'iroqlar jurnali buyruqlari
        val callType = when {
            spoken.contains("kiruvchi") || spoken.contains("kiruchi") -> "kiruvchi"
            spoken.contains("chiquvchi") || spoken.contains("chiquchi") -> "chiquvchi"
            spoken.contains("berilmagan") || spoken.contains("otkazib") -> "berilmagan"
            spoken.contains("oxirgi") -> null
            else -> "NONE"
        }
        if (callType != "NONE") {
            val action = when {
                spoken.contains("telegram") -> "telegram"
                spoken.contains("whatsapp") -> "whatsapp"
                spoken.contains("nusxalash") -> "nusxalash"
                spoken.contains("xabar") -> "xabar"
                spoken.contains("saqlash") -> "saqlash"
                else -> "call"
            }
            if (noSpace.contains("royxat") || noSpace.contains("ro'yxat")) {
                val title = when (callType) {
                    "kiruvchi" -> "Kiruvchi qo'ng'iroqlar"
                    "chiquvchi" -> "Chiquvchi qo'ng'iroqlar"
                    "berilmagan" -> "Javob berilmagan qo'ng'iroqlar"
                    else -> "Oxirgi qo'ng'iroqlar"
                }
                (activity as MainActivity).navigateTo(CallLogFragment.newInstance(callType, title))
            } else {
                executeCallLogAction(callType, action)
            }
            if (permanent) startVoicePermanent()
            return
        }

        // Kartoteka qidirish
        if (noSpace.contains("kartoteka")) {
            val query = spoken.replace("kartoteka", "").trim()
            if (query.isEmpty()) {
                (activity as MainActivity).navigateTo(KartotekaFragment())
            } else {
                (activity as MainActivity).navigateTo(KartotekaFragment.newInstance(query))
            }
            if (permanent) startVoicePermanent()
            return
        }

        // Qidiruv
        if (noSpace.contains("qidirish") || noSpace.contains("qidiruv") || noSpace.contains("kidirish")) {
            (activity as MainActivity).navigateTo(UniversalSearchFragment())
            if (permanent) startVoicePermanent()
            return
        }

        // Kontakt bo'yicha amal
        val actionMap = mapOf(
            "nusxalash" to "nusxalash", "saqlash" to "saqlash",
            "telegram" to "telegram", "whatsapp" to "whatsapp",
            "xabar" to "xabar", "chaqirish" to "call"
        )
        var action = "call"
        var query = spoken
        for ((key, val_) in actionMap) {
            if (spoken.contains(key)) {
                action = val_; query = spoken.replace(key, "").trim(); break
            }
        }

        if (query.isNotEmpty()) {
            val results = ContactUtils.searchContacts(ctx(), query)
            when {
                results.isEmpty() -> Toast.makeText(ctx(), "$query topilmadi", Toast.LENGTH_SHORT).show()
                results.size == 1 -> executeContactAction(action, results[0].num)
                else -> {
                    val items = results.map { it.display }.toTypedArray()
                    AlertDialog.Builder(ctx()).setTitle("Qidiruv natijalari")
                        .setItems(items) { _, i -> executeContactAction(action, results[i].num) }
                        .show()
                }
            }
        } else {
            Toast.makeText(ctx(), "Tushunarsiz buyruq", Toast.LENGTH_SHORT).show()
        }
        if (permanent) startVoicePermanent()
    }

    private fun executeContactAction(action: String, num: String) {
        when (action) {
            "call" -> startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "nusxalash" -> {
                val cm = ctx().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("l", num))
                Toast.makeText(ctx(), "Nusxalandi: ${TextUtils.formatPhoneForVoice(num)}", Toast.LENGTH_SHORT).show()
            }
            "telegram" -> {
                val n = num.replace(Regex("[^\\d]"), "").removePrefix("998")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            }
            "whatsapp" -> {
                val n = num.replace(Regex("[^\\d]"), "").removePrefix("998")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            }
            "xabar" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "saqlash" -> saveContact(num)
        }
    }

    private fun executeCallLogAction(callType: String?, action: String) {
        val entry = ContactUtils.getCallLogEntry(ctx(), callType)
        if (entry == null) { Toast.makeText(ctx(), "Qo'ng'iroq topilmadi", Toast.LENGTH_SHORT).show(); return }
        when (action) {
            "call" -> startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${entry.num}")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "nusxalash" -> {
                val cm = ctx().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("l", entry.num))
                Toast.makeText(ctx(), "Nusxalandi: ${TextUtils.formatPhoneForVoice(entry.num)}", Toast.LENGTH_SHORT).show()
            }
            "telegram" -> {
                val n = entry.num.replace(Regex("[^\\d]"), "").removePrefix("998")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            }
            "whatsapp" -> {
                val n = entry.num.replace(Regex("[^\\d]"), "").removePrefix("998")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            }
            "xabar" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${entry.num}")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            "saqlash" -> saveContact(entry.num)
        }
    }

    private fun saveContact(num: String) {
        val existing = ContactUtils.findContactName(ctx(), num)
        if (existing != null) {
            Toast.makeText(ctx(), "Bu raqam $existing nomi bilan saqlangan", Toast.LENGTH_LONG).show(); return
        }
        val edit = android.widget.EditText(ctx()).apply { hint = "Ismni kiriting..." }
        AlertDialog.Builder(ctx()).setTitle("Ism kiriting").setView(edit)
            .setPositiveButton("Saqlash") { _, _ ->
                val name = TextUtils.capitalizeFirst(edit.text.toString()).ifEmpty { "Yangi" }
                val it = Intent(Intent.ACTION_INSERT).apply {
                    type = ContactsContract.RawContacts.CONTENT_TYPE
                    putExtra(ContactsContract.Intents.Insert.NAME, name)
                    putExtra(ContactsContract.Intents.Insert.PHONE, num)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(it)
            }.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        voiceManager.destroy()
    }
}
