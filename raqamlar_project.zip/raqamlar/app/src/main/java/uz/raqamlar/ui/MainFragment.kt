package uz.raqamlar.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.Say

class MainFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_main, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val act = activity as MainActivity

        view.findViewById<Button>(R.id.btnVoice).setOnClickListener { act.startVoiceCommand() }
        view.findViewById<Button>(R.id.btnSearch).setOnClickListener { act.navigateTo(UniversalSearchFragment()) }
        view.findViewById<Button>(R.id.btnKartoteka).setOnClickListener { act.navigateTo(KartotekaFragment()) }
        view.findViewById<Button>(R.id.btnSettings).setOnClickListener { act.navigateTo(SettingsFragment()) }

        setupCallButton(view, R.id.btnKiruvchi, "kiruvchi", "Kiruvchi qo'ng'iroqlar")
        setupCallButton(view, R.id.btnChiquvchi, "chiquvchi", "Chiquvchi qo'ng'iroqlar")
        setupCallButton(view, R.id.btnBerilmagan, "berilmagan", "Javobsiz qo'ng'iroqlar")
        setupCallButton(view, R.id.btnOxirgi, null, "Oxirgi qo'ng'iroqlar")
    }

    private fun setupCallButton(view: View, btnId: Int, callType: String?, title: String) {
        val btn = view.findViewById<Button>(btnId)
        btn.setOnClickListener {
            val entry = ContactUtils.getCallLogEntry(requireContext(), callType)
            if (entry == null) {
                Say.show(requireContext(), "Qo'ng'iroq topilmadi")
            } else {
                Flows.call(requireContext(), entry.num)
            }
        }
        btn.setOnLongClickListener {
            (activity as MainActivity).navigateTo(CallLogFragment.newInstance(callType, title))
            true
        }
    }
}
