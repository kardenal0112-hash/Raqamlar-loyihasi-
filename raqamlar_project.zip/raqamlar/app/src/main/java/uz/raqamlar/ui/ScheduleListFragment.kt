package uz.raqamlar.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.data.ScheduleRepo

class ScheduleListFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_schedule_list, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility("Jadval bo'yicha ish tartibi")
        view.findViewById<Button>(R.id.btnAddSchedule).setOnClickListener {
            (activity as MainActivity).navigateTo(ScheduleEditFragment.newInstance(-1, null))
        }
        loadList(view)
    }

    private fun loadList(view: View) {
        val list = ScheduleRepo.getAll(requireContext())
        val display = list.mapIndexed { i, e ->
            val modeLabel = if (e.mode == "voice") "Ovozli rejim" else "Vizual rejim"
            "${ScheduleRepo.formatDays(e.days)}, ${e.start}–${e.stop} — $modeLabel"
        }
        val lv = view.findViewById<ListView>(R.id.listSchedule)
        lv.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, display)

        lv.setOnItemClickListener { _, _, pos, _ ->
            (activity as MainActivity).navigateTo(ScheduleEditFragment.newInstance(pos, list[pos].mode))
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(requireContext())
                .setTitle("O'chirish")
                .setMessage("Ushbu vaqt oralig'ini o'chirishni tasdiqlaysizmi?")
                .setPositiveButton("Ha, o'chirish") { _, _ ->
                    val updated = list.toMutableList().also { it.removeAt(pos) }
                    ScheduleRepo.saveAll(requireContext(), updated)
                    loadList(view)
                }
                .setNegativeButton("Bekor qilish", null).show()
            true
        }
    }
}
