package uz.raqamlar.voice

import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import uz.raqamlar.MainActivity
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.TextUtils

// Ilovaning o'z matn maydonlarida ovozdan yozish (plagindagi diktovka bilan bir xil):
// maydonda matn bo'lsa avval o'chiriladi, so'ng darhol tinglanadi.
object Dictation {

    fun findEdit(root: View): EditText? {
        var focused: EditText? = null
        var first: EditText? = null

        fun walk(v: View) {
            if (v is EditText && v.isShown) {
                if (first == null) first = v
                if (v.isFocused && focused == null) focused = v
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
        }

        walk(root)
        return focused ?: first
    }

    private fun fieldType(e: EditText): String {
        val h = e.hint?.toString() ?: ""
        return when {
            h.startsWith("Ismni") || h.startsWith("Ism kiriting") -> "name"
            (e.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER -> "digits"
            else -> "alnum"
        }
    }

    fun start(act: MainActivity, edit: EditText) {
        val type = fieldType(edit)
        if (edit.text.isNotEmpty()) edit.setText("")

        if (!act.voice.isNetworkAvailable()) {
            Say.show(act, "Internet aloqasi yo'q", true)
            return
        }

        act.voice.startListening(object : VoiceManager.Listener {
            override fun onResult(spoken: String) {
                val finalText = when (type) {
                    "digits" -> spoken.replace(Regex("[^\\d]"), "")
                    "name" -> TextUtils.capitalizeAll(spoken)
                    else -> spoken
                }
                edit.setText(finalText)
                edit.setSelection(edit.text.length)
                if (finalText.isEmpty()) {
                    Say.show(act, "Yaroqli matn topilmadi")
                } else {
                    edit.announceForAccessibility(finalText)
                }
            }

            override fun onError(code: Int) {
                Say.show(act, "Eshitilmadi")
            }
        })
    }
}
