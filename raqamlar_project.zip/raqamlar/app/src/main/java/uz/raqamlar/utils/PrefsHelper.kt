package uz.raqamlar.utils

import android.content.Context

object PrefsHelper {
    private const val PREFS = "raqamlar_prefs"
    private const val KEY_HIDE = "hide_"
    private const val KEY_ADD  = "add_"
    private const val KEY_VOLUME = "volume_keys_enabled"

    fun isVolumeKeys(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, 0).getBoolean(KEY_VOLUME, true)

    fun setVolumeKeys(ctx: Context, state: Boolean) {
        ctx.getSharedPreferences(PREFS, 0).edit().putBoolean(KEY_VOLUME, state).apply()
    }

    fun isHidden(ctx: Context, pkg: String): Boolean =
        ctx.getSharedPreferences(PREFS, 0).getBoolean("$KEY_HIDE$pkg", false)

    fun isForceAdded(ctx: Context, pkg: String): Boolean =
        ctx.getSharedPreferences(PREFS, 0).getBoolean("$KEY_ADD$pkg", false)

    fun addApp(ctx: Context, pkg: String) {
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putBoolean("$KEY_ADD$pkg", true).remove("$KEY_HIDE$pkg").apply()
    }

    fun hideApp(ctx: Context, pkg: String) {
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putBoolean("$KEY_HIDE$pkg", true).remove("$KEY_ADD$pkg").apply()
    }
}
