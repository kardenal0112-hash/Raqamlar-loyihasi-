package uz.raqamlar.utils

import android.content.Context

object PrefsHelper {
    private const val PREFS = "raqamlar_prefs"
    private const val KEY_VOICE = "voice_control_enabled"
    private const val KEY_HIDE = "hide_"
    private const val KEY_ADD  = "add_"

    fun isVoiceMode(ctx: Context) =
        ctx.getSharedPreferences(PREFS, 0).getBoolean(KEY_VOICE, false)

    fun setVoiceMode(ctx: Context, state: Boolean) =
        ctx.getSharedPreferences(PREFS, 0).edit().putBoolean(KEY_VOICE, state).apply()

    fun isHidden(ctx: Context, pkg: String) =
        ctx.getSharedPreferences(PREFS, 0).getBoolean("$KEY_HIDE$pkg", false)

    fun isForceAdded(ctx: Context, pkg: String) =
        ctx.getSharedPreferences(PREFS, 0).getBoolean("$KEY_ADD$pkg", false)

    fun addApp(ctx: Context, pkg: String) =
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putBoolean("$KEY_ADD$pkg", true).remove("$KEY_HIDE$pkg").apply()

    fun hideApp(ctx: Context, pkg: String) =
        ctx.getSharedPreferences(PREFS, 0).edit()
            .putBoolean("$KEY_HIDE$pkg", true).remove("$KEY_ADD$pkg").apply()
}
