package uz.raqamlar.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import androidx.fragment.app.Fragment
import uz.raqamlar.R
import uz.raqamlar.utils.PrefsHelper
import uz.raqamlar.utils.Say

class SettingsFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_settings, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext()

        val cb = view.findViewById<CheckBox>(R.id.cbVolumeKeys)
        cb.isChecked = PrefsHelper.isVolumeKeys(ctx)
        cb.setOnCheckedChangeListener { _, checked ->
            PrefsHelper.setVolumeKeys(ctx, checked)
            Say.show(ctx, if (checked) "Ovoz tugmasi bilan boshqarish yoqildi" else "Ovoz tugmasi bilan boshqarish o'chirildi")
        }

        view.findViewById<Button>(R.id.btnAppPermissions).setOnClickListener { openAppDetails() }

        view.findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } else {
                    openAppDetails()
                }
            } catch (e: Exception) {
                openAppDetails()
            }
        }
    }

    private fun openAppDetails() {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.fromParts("package", requireContext().packageName, null)
            startActivity(i)
        } catch (e: Exception) {
            Say.show(requireContext(), "Sozlamalarni ochib bo'lmadi")
        }
    }
}
