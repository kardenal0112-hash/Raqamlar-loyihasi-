package uz.raqamlar.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.TextUtils

class UniversalSearchFragment : Fragment() {

    private lateinit var editSearch: EditText
    private lateinit var listResults: ListView

    private val act: MainActivity get() = activity as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_universal_search, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility("Universal qidiruv")
        editSearch = view.findViewById(R.id.editSearch)
        listResults = view.findViewById(R.id.listResults)
        view.findViewById<Button>(R.id.btnSearch).setOnClickListener { performSearch() }
    }

    private fun showList(items: List<String>) {
        listResults.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, items)
    }

    private fun performSearch() {
        val raw = editSearch.text.toString().trim()
        if (raw.isEmpty()) return
        val digits = raw.replace(Regex("[^\\d]"), "")

        // 16 xonali karta raqami
        if (digits.length == 16) {
            if (!TextUtils.isValidLuhn(digits)) {
                Say.show(requireContext(), "karta raqami noto'g'ri kiritildi")
                editSearch.setText("")
                return
            }
            val bankName = TextUtils.getBankName(digits)
            showList(listOf("$bankName: ${TextUtils.formatCardForVoice(digits)}"))
            listResults.setOnItemClickListener { _, _, _, _ -> Flows.showSummaDialog(act, digits) }
            listResults.setOnItemLongClickListener { _, _, _, _ ->
                Flows.showFinalActions(act, digits, true, bankName)
                true
            }
            return
        }

        // Telefon raqami (9 yoki 12 xona)
        if (digits.length == 9 || digits.length == 12) {
            val full = if (digits.length == 9) "+998$digits" else "+$digits"
            showList(listOf(TextUtils.formatPhoneForVoice(full)))
            listResults.setOnItemClickListener { _, _, _, _ -> Flows.call(requireContext(), full) }
            listResults.setOnItemLongClickListener { _, _, _, _ ->
                Flows.showFinalActions(act, full, false, "Raqam")
                true
            }
            return
        }

        // Ism yoki raqam bo'lagi bo'yicha
        val contacts = ContactUtils.searchContacts(requireContext(), raw)
        if (contacts.isEmpty()) {
            Say.show(requireContext(), "Hech narsa topilmadi")
            editSearch.setText("")
            return
        }
        val display = ArrayList<String>()
        val nums = ArrayList<String>()
        for (c in contacts) {
            display.add(c.display)
            nums.add(c.num)
        }
        showList(display)
        listResults.setOnItemClickListener { _, _, pos, _ -> Flows.call(requireContext(), nums[pos]) }
        listResults.setOnItemLongClickListener { _, _, pos, _ ->
            Flows.showFinalActions(act, nums[pos], false, "Raqam")
            true
        }
    }
}
