package uz.raqamlar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.R
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.TextUtils
import uz.raqamlar.voice.VoiceManager

class UniversalSearchFragment : Fragment() {

    private lateinit var editSearch: EditText
    private lateinit var listResults: ListView
    private lateinit var voiceManager: VoiceManager
    private var currentResults = listOf<String>()
    private var currentNums = listOf<String>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_universal_search, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility("Universal qidiruv")
        editSearch = view.findViewById(R.id.editSearch)
        listResults = view.findViewById(R.id.listResults)
        voiceManager = VoiceManager(requireContext())

        view.findViewById<Button>(R.id.btnSearch).setOnClickListener { performSearch() }
        view.findViewById<Button>(R.id.btnMic).setOnClickListener {
            voiceManager.startListening(object : VoiceManager.Listener {
                override fun onResult(spoken: String) {
                    editSearch.setText(spoken); performSearch()
                }
                override fun onError(code: Int) { Toast.makeText(requireContext(), "Eshitilmadi", Toast.LENGTH_SHORT).show() }
            })
        }
    }

    private fun performSearch() {
        val raw = editSearch.text.toString().trim()
        if (raw.isEmpty()) return
        val digits = raw.replace(Regex("[^\\d]"), "")

        // 16 xonali karta raqami
        if (digits.length == 16) {
            if (!TextUtils.isValidLuhn(digits)) {
                Toast.makeText(requireContext(), "Karta raqami noto'g'ri", Toast.LENGTH_SHORT).show(); return
            }
            val bankName = TextUtils.getBankName(digits)
            showSingleResult("$bankName: ${TextUtils.formatCardForVoice(digits)}", digits, isCard = true)
            return
        }

        // Telefon raqami
        if (digits.length == 9 || digits.length == 12) {
            val full = if (digits.length == 9) "+998$digits" else "+$digits"
            showSingleResult(TextUtils.formatPhoneForVoice(full), full, isCard = false)
            return
        }

        // Ism bo'yicha qidiruv
        val contacts = ContactUtils.searchContacts(requireContext(), raw)
        if (contacts.isEmpty()) {
            Toast.makeText(requireContext(), "Hech narsa topilmadi", Toast.LENGTH_SHORT).show(); return
        }
        currentResults = contacts.map { it.display }
        currentNums    = contacts.map { it.num }
        listResults.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, currentResults)
        listResults.setOnItemClickListener { _, _, pos, _ ->
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${currentNums[pos]}"))
                .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        }
        listResults.setOnItemLongClickListener { _, _, pos, _ ->
            showPhoneActions(currentNums[pos]); true
        }
    }

    private fun showSingleResult(display: String, num: String, isCard: Boolean) {
        currentResults = listOf(display)
        currentNums    = listOf(num)
        listResults.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, currentResults)
        listResults.setOnItemClickListener { _, _, _, _ ->
            if (isCard) showCardActions(num) else showPhoneActions(num)
        }
        listResults.setOnItemLongClickListener { _, _, _, _ ->
            if (isCard) showCardActions(num) else showPhoneActions(num); true
        }
    }

    private fun showPhoneActions(num: String) {
        val options = arrayOf("Qo'ng'iroq qilish", "Nusxalab olish", "Telegram", "WhatsApp", "Xabar jo'natish", "Kontaktga saqlash")
        AlertDialog.Builder(requireContext())
            .setTitle(TextUtils.formatPhoneForVoice(num))
            .setItems(options) { _, w ->
                when (w) {
                    0 -> startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                    1 -> { clipboard(num); Toast.makeText(requireContext(), "Nusxalandi", Toast.LENGTH_SHORT).show() }
                    2 -> { val n = num.replace(Regex("[^\\d]"), "").removePrefix("998")
                           startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }) }
                    3 -> { val n = num.replace(Regex("[^\\d]"), "").removePrefix("998")
                           startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }) }
                    4 -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                    5 -> { val ed = EditText(requireContext()).apply { hint = "Ismni kiriting..." }
                           AlertDialog.Builder(requireContext()).setTitle("Ism kiriting").setView(ed)
                               .setPositiveButton("Saqlash") { _, _ ->
                                   val n = TextUtils.capitalizeFirst(ed.text.toString()).ifEmpty { "Yangi" }
                                   val it2 = Intent(Intent.ACTION_INSERT).apply {
                                       type = android.provider.ContactsContract.RawContacts.CONTENT_TYPE
                                       putExtra(android.provider.ContactsContract.Intents.Insert.NAME, n)
                                       putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, num)
                                       flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                   }
                                   startActivity(it2)
                               }.show() }
                }
            }.show()
    }

    private fun showCardActions(num: String) {
        val bankName = TextUtils.getBankName(num)
        val options = arrayOf("Nusxalab olish", "To'lov / O'tkazma")
        AlertDialog.Builder(requireContext())
            .setTitle("$bankName: ${TextUtils.formatCardForVoice(num)}")
            .setItems(options) { _, w ->
                when (w) {
                    0 -> { clipboard(num); Toast.makeText(requireContext(), "Nusxalandi", Toast.LENGTH_SHORT).show() }
                    1 -> { clipboard(num); Toast.makeText(requireContext(), "Karta raqami nusxalandi. Bank ilovasini oching va maydonga joylang.", Toast.LENGTH_LONG).show() }
                }
            }.show()
    }

    private fun clipboard(text: String) {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("l", text))
    }

    override fun onDestroyView() { super.onDestroyView(); voiceManager.destroy() }
}
