package uz.raqamlar.utils

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract

data class CallEntry(val num: String, val name: String)
data class ContactEntry(val display: String, val num: String)

object ContactUtils {

    fun findContactName(context: Context, phoneNum: String): String? {
        val last9 = phoneNum.replace(Regex("[^\\d]"), "").takeLast(9)
        val cr = context.contentResolver
        val cursor = cr.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null, null, null, null
        ) ?: return null
        var found: String? = null
        cursor.use {
            while (it.moveToNext()) {
                val num = it.getString(it.getColumnIndexOrThrow("data1")) ?: continue
                val name = it.getString(it.getColumnIndexOrThrow("display_name")) ?: continue
                val c = num.replace(Regex("[^\\d]"), "")
                if (c.length >= 9 && c.takeLast(9) == last9 && name.isNotEmpty()) {
                    found = name; break
                }
            }
        }
        return found
    }

    fun getCallLogList(context: Context, callType: String?): List<CallEntry> {
        val cr = context.contentResolver
        // Kontaktlarni oldindan yuklab olamiz
        val contactMap = mutableMapOf<String, String>()
        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val num = c.getString(c.getColumnIndexOrThrow("data1")) ?: continue
                val name = c.getString(c.getColumnIndexOrThrow("display_name")) ?: continue
                val d = num.replace(Regex("[^\\d]"), "")
                if (d.length >= 9 && name.isNotEmpty()) contactMap[d.takeLast(9)] = name
            }
        }

        val selection = when (callType) {
            "kiruvchi" -> "type = ${CallLog.Calls.INCOMING_TYPE}"
            "chiquvchi" -> "type = ${CallLog.Calls.OUTGOING_TYPE}"
            "berilmagan" -> "type = ${CallLog.Calls.MISSED_TYPE}"
            else -> null
        }

        val results = mutableListOf<CallEntry>()
        val seen = mutableSetOf<String>()
        cr.query(CallLog.Calls.CONTENT_URI, null, selection, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                val numIdx = c.getColumnIndex("number")
                val nameIdx = c.getColumnIndex("cached_name")
                val num = if (numIdx >= 0) c.getString(numIdx) ?: "" else ""
                val cachedName = if (nameIdx >= 0) c.getString(nameIdx) ?: "" else ""
                val digits = num.replace(Regex("[^\\d]"), "")
                val full = when {
                    digits.length == 9 -> "+998$digits"
                    digits.length == 12 -> "+$digits"
                    else -> num
                }
                if (full.isNotEmpty() && seen.add(full)) {
                    val displayName = contactMap[digits.takeLast(9)] ?: cachedName
                    results.add(CallEntry(full, displayName))
                }
            }
        }
        return results
    }

    fun getCallLogEntry(context: Context, callType: String?): CallEntry? {
        return getCallLogList(context, callType).firstOrNull()
    }

    fun searchContacts(context: Context, query: String): List<ContactEntry> {
        val skel = TextUtils.getSkel(query)
        val cleanNum = query.replace(Regex("[^\\d]"), "")
        val results = mutableListOf<ContactEntry>()
        val seen = mutableSetOf<String>()
        val cr = context.contentResolver

        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(c.getColumnIndexOrThrow("display_name")) ?: ""
                val num = c.getString(c.getColumnIndexOrThrow("data1")) ?: ""
                val digits = num.replace(Regex("[^\\d]"), "")
                if (digits.length < 3) continue
                val match = (skel.length >= 2 && TextUtils.getSkel(name).contains(skel)) ||
                            (cleanNum.length >= 4 && digits.contains(cleanNum))
                if (match) {
                    val full = when {
                        digits.length in 3..7 -> digits
                        digits.length == 9 -> "+998$digits"
                        else -> "+$digits"
                    }
                    if (seen.add(full)) {
                        results.add(ContactEntry("$name: ${TextUtils.formatPhoneForVoice(full)}", full))
                    }
                }
            }
        }

        // Qo'ng'iroqlar jurnalidan ham qidirish (raqam bo'yicha)
        if (results.size < 15 && cleanNum.length >= 4) {
            cr.query(CallLog.Calls.CONTENT_URI, null, null, null, "date DESC")?.use { c ->
                while (c.moveToNext()) {
                    val num = c.getString(c.getColumnIndex("number")) ?: ""
                    val digits = num.replace(Regex("[^\\d]"), "")
                    if (digits.length >= 9 && digits.contains(cleanNum)) {
                        val full = if (digits.length == 9) "+998$digits" else "+$digits"
                        if (seen.add(full)) {
                            results.add(ContactEntry(TextUtils.formatPhoneForVoice(full), full))
                        }
                    }
                    if (results.size >= 15) break
                }
            }
        }
        return results
    }
    // Ovozli buyruq uchun qidiruv (plagindagidek): ism skeleti yoki oxirgi 4 ta raqam
    fun searchContactsVoice(context: Context, query: String): List<ContactEntry> {
        val skel = TextUtils.getSkel(query)
        val cleanQ = query.replace(Regex("[^\\d]"), "")
        val results = mutableListOf<ContactEntry>()
        val seen = mutableSetOf<String>()
        val cr = context.contentResolver

        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(c.getColumnIndexOrThrow("display_name")) ?: ""
                val num = c.getString(c.getColumnIndexOrThrow("data1")) ?: ""
                val digits = num.replace(Regex("[^\\d]"), "")
                if (digits.length < 3) continue
                val match = (skel.length >= 2 && TextUtils.getSkel(name).contains(skel)) ||
                            (cleanQ.length == 4 && digits.endsWith(cleanQ))
                if (match) {
                    val full = when {
                        digits.length in 3..7 -> digits
                        digits.length == 9 -> "+998$digits"
                        else -> "+$digits"
                    }
                    if (seen.add(full)) {
                        results.add(ContactEntry("$name: ${TextUtils.formatPhoneForVoice(full)}", full))
                    }
                }
            }
        }

        if (results.size < 10 && cleanQ.length >= 4) {
            cr.query(CallLog.Calls.CONTENT_URI, null, null, null, "date DESC")?.use { c ->
                val numIdx = c.getColumnIndex("number")
                while (c.moveToNext()) {
                    val num = if (numIdx >= 0) c.getString(numIdx) ?: "" else ""
                    val digits = num.replace(Regex("[^\\d]"), "")
                    if (digits.length >= 9 && digits.endsWith(cleanQ)) {
                        val full = if (digits.length == 9) "+998$digits" else "+$digits"
                        if (seen.add(full)) {
                            results.add(ContactEntry(TextUtils.formatPhoneForVoice(full), full))
                        }
                    }
                    if (results.size >= 15) break
                }
            }
        }
        return results
    }
}
