package uz.raqamlar.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import uz.raqamlar.R
import uz.raqamlar.data.LocationEntry
import uz.raqamlar.data.LocationRepo
import uz.raqamlar.utils.TextUtils

class LocationEditFragment : Fragment() {

    companion object {
        private const val REQ_LOC = 200
        fun newInstance(index: Int) = LocationEditFragment().apply {
            arguments = Bundle().apply { putInt("index", index) }
        }
    }

    private var capturedLat: Double? = null
    private var capturedLon: Double? = null
    private var locationListener: LocationListener? = null
    private lateinit var tvStatus: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_location_edit, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val index    = arguments?.getInt("index", -1) ?: -1
        val list     = LocationRepo.getAll(requireContext())
        val existing = if (index >= 0 && index < list.size) list[index] else null

        view.announceForAccessibility(if (existing == null) "Yangi joy qo'shish" else "Joyni tahrirlash")

        val edName = view.findViewById<EditText>(R.id.edLocationName)
        val rgMode = view.findViewById<RadioGroup>(R.id.rgLocationMode)
        tvStatus   = view.findViewById(R.id.tvLocationStatus)
        val btnSaveLoc = view.findViewById<Button>(R.id.btnSaveLocation)

        existing?.let {
            edName.setText(it.name)
            capturedLat = it.lat; capturedLon = it.lon
            if (it.mode == "voice") rgMode.check(R.id.rbLocVoice) else rgMode.check(R.id.rbLocVisual)
            tvStatus.text = "Joylashuv: avval saqlangan"
        }

        btnSaveLoc.setOnClickListener { requestAndSaveLocation(btnSaveLoc) }

        view.findViewById<Button>(R.id.btnSaveEntry).setOnClickListener {
            val name = TextUtils.capitalizeFirst(edName.text.toString())
            if (name.isEmpty()) { Toast.makeText(requireContext(), "Ism kiritilmadi", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (capturedLat == null) { Toast.makeText(requireContext(), "Avval joylashuvni saqlang", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val mode = if (rgMode.checkedRadioButtonId == R.id.rbLocVoice) "voice" else "visual"
            val radius = existing?.radius ?: 150
            val newEntry = LocationEntry(name, capturedLat!!, capturedLon!!, radius, mode)
            val updated = list.toMutableList()
            if (index >= 0) updated.removeAt(index)
            updated.add(newEntry)
            LocationRepo.saveAll(requireContext(), updated)
            Toast.makeText(requireContext(), "Saqlandi", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }
    }

    private fun requestAndSaveLocation(btnSaveLoc: Button) {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(requireContext()).setTitle("Ruxsat kerak")
                .setMessage("Joylashuvni saqlash uchun GPS ruxsati kerak. Sozlamalarga o'tamizmi?")
                .setPositiveButton("Sozlamalar") { _, _ ->
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:${requireContext().packageName}")))
                }.setNegativeButton("Bekor qilish", null).show()
            return
        }
        tvStatus.text = "Joylashuv aniqlanmoqda..."
        btnSaveLoc.isEnabled = false

        val lm = requireContext().getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
        var finished = false
        var bestLoc: Location? = null

        fun finishCapture() {
            if (finished) return; finished = true
            try { locationListener?.let { lm.removeUpdates(it) } } catch (_: Exception) {}
            activity?.runOnUiThread {
                btnSaveLoc.isEnabled = true
                val final = bestLoc ?: LocationRepo.getCachedLocation(requireContext())
                if (final != null) {
                    capturedLat = final.latitude; capturedLon = final.longitude
                    tvStatus.text = "Joylashuv olindi ✓"
                } else {
                    tvStatus.text = "Joylashuv topilmadi, qayta urinib ko'ring"
                }
            }
        }

        locationListener = LocationListener { loc ->
            if (bestLoc == null || loc.accuracy < bestLoc!!.accuracy) bestLoc = loc
        }

        try {
            var requested = false
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, locationListener!!, null)
                requested = true
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, locationListener!!, null)
                requested = true
            }
            if (!requested) finishCapture()
        } catch (_: Exception) { finishCapture() }

        // 5 soniyadan keyin majburiy tugash
        view?.postDelayed({ finishCapture() }, 5000)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        try {
            val lm = requireContext().getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            locationListener?.let { lm.removeUpdates(it) }
        } catch (_: Exception) {}
    }
}
