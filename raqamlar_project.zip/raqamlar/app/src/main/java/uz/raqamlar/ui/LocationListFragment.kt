package uz.raqamlar.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.data.LocationRepo

class LocationListFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_location_list, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.announceForAccessibility("Joylashuv bo'yicha ish tartibi")
        view.findViewById<Button>(R.id.btnAddLocation).setOnClickListener {
            (activity as MainActivity).navigateTo(LocationEditFragment.newInstance(-1))
        }
        loadList(view)
    }

    private fun loadList(view: View) {
        val list = LocationRepo.getAll(requireContext())
        val display = list.map { e ->
            val modeLabel = if (e.mode == "voice") "Ovozli rejim" else "Vizual rejim"
            "${e.name} (${e.radius} m) — $modeLabel"
        }
        val lv = view.findViewById<ListView>(R.id.listLocations)
        lv.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, display)

        lv.setOnItemClickListener { _, _, pos, _ ->
            (activity as MainActivity).navigateTo(LocationEditFragment.newInstance(pos))
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            val entry = list[pos]
            val opts = arrayOf("Radiusni o'zgartirish", "Qayta nomlash", "O'chirish")
            AlertDialog.Builder(requireContext()).setTitle(entry.name).setItems(opts) { _, w ->
                when (w) {
                    0 -> {
                        val ed = EditText(requireContext()).apply {
                            hint = "Radius (metrda)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
                            setText(entry.radius.toString())
                        }
                        AlertDialog.Builder(requireContext()).setTitle("Radiusni o'zgartirish").setView(ed)
                            .setPositiveButton("Saqlash") { _, _ ->
                                val r = ed.text.toString().toIntOrNull()
                                if (r != null && r > 0) {
                                    val updated = list.toMutableList()
                                    updated[pos] = entry.copy(radius = r)
                                    LocationRepo.saveAll(requireContext(), updated)
                                    loadList(view)
                                } else Toast.makeText(requireContext(), "Radius noto'g'ri", Toast.LENGTH_SHORT).show()
                            }.show()
                    }
                    1 -> {
                        val ed = EditText(requireContext()).apply { setText(entry.name) }
                        AlertDialog.Builder(requireContext()).setTitle("Qayta nomlash").setView(ed)
                            .setPositiveButton("Saqlash") { _, _ ->
                                val newName = ed.text.toString().trim()
                                if (newName.isNotEmpty()) {
                                    val updated = list.toMutableList()
                                    updated[pos] = entry.copy(name = newName)
                                    LocationRepo.saveAll(requireContext(), updated)
                                    loadList(view)
                                }
                            }.show()
                    }
                    2 -> {
                        AlertDialog.Builder(requireContext()).setTitle("O'chirish")
                            .setMessage("${entry.name} ni o'chirishni tasdiqlaysizmi?")
                            .setPositiveButton("Ha, o'chirish") { _, _ ->
                                val updated = list.toMutableList().also { it.removeAt(pos) }
                                LocationRepo.saveAll(requireContext(), updated)
                                loadList(view)
                            }.setNegativeButton("Bekor qilish", null).show()
                    }
                }
            }.show()
            true
        }
    }
}
