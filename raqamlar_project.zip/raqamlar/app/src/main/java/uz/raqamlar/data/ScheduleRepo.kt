package uz.raqamlar.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class ScheduleEntry(
    val start: String,   // "HH:MM"
    val stop: String,    // "HH:MM"
    val days: List<Int>?, // 1=Yakshanba..7=Shanba, null=har kuni
    val mode: String     // "voice" yoki "visual"
)

object ScheduleRepo {
    private const val PREFS = "ish_tartibi_data"
    private const val KEY   = "schedule_json"

    val DAY_LABELS = arrayOf("Dush", "Sesh", "Chor", "Pay", "Jum", "Shan", "Yak")
    // Calendar.MONDAY=2..SATURDAY=7, SUNDAY=1
    val DAY_VALUES = intArrayOf(2, 3, 4, 5, 6, 7, 1)

    fun getAll(ctx: Context): MutableList<ScheduleEntry> {
        val json = ctx.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val list = mutableListOf<ScheduleEntry>()
        return try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val daysArr = if (o.has("days") && !o.isNull("days")) {
                    val da = o.getJSONArray("days")
                    (0 until da.length()).map { da.getInt(it) }
                } else null
                list.add(ScheduleEntry(o.getString("start"), o.getString("stop"), daysArr, o.getString("mode")))
            }
            list
        } catch (e: Exception) { list }
    }

    fun saveAll(ctx: Context, list: List<ScheduleEntry>) {
        val arr = JSONArray()
        list.forEach { e ->
            val o = JSONObject()
            o.put("start", e.start)
            o.put("stop", e.stop)
            if (e.days != null) {
                val da = JSONArray(); e.days.forEach { da.put(it) }
                o.put("days", da)
            } else o.put("days", JSONObject.NULL)
            o.put("mode", e.mode)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }

    private fun timeToMinutes(t: String): Int {
        val parts = t.split(":")
        return if (parts.size == 2) (parts[0].toIntOrNull() ?: 0) * 60 + (parts[1].toIntOrNull() ?: 0)
        else 0
    }

    private fun isInRange(now: Int, start: Int, stop: Int): Boolean =
        if (start <= stop) now >= start && now < stop
        else now >= start || now < stop

    private fun dayMatches(days: List<Int>?, wday: Int): Boolean =
        days == null || days.isEmpty() || days.contains(wday)

    fun checkMode(ctx: Context): String? {
        val cal = Calendar.getInstance()
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val wday = cal.get(Calendar.DAY_OF_WEEK)
        for (e in getAll(ctx)) {
            val start = timeToMinutes(e.start)
            val stop  = timeToMinutes(e.stop)
            if (dayMatches(e.days, wday) && isInRange(nowMin, start, stop)) return e.mode
        }
        return null
    }

    fun formatDays(days: List<Int>?): String {
        if (days == null || days.isEmpty()) return "Har kuni"
        val labels = mutableListOf<String>()
        DAY_VALUES.forEachIndexed { i, dv -> if (days.contains(dv)) labels.add(DAY_LABELS[i]) }
        return labels.joinToString(", ")
    }

    fun timesOverlap(s1: Int, e1: Int, s2: Int, e2: Int): Boolean {
        fun split(s: Int, e: Int) = if (s <= e) listOf(Pair(s,e)) else listOf(Pair(s,1440), Pair(0,e))
        for (a in split(s1, e1)) for (b in split(s2, e2)) if (a.first < b.second && b.first < a.second) return true
        return false
    }

    fun daysOverlap(d1: List<Int>?, d2: List<Int>?): Boolean {
        val all = listOf(1,2,3,4,5,6,7)
        val s1 = if (d1.isNullOrEmpty()) all else d1
        val s2 = if (d2.isNullOrEmpty()) all else d2
        return s1.any { s2.contains(it) }
    }
}
