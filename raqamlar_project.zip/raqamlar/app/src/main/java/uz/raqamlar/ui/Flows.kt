package uz.raqamlar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import uz.raqamlar.MainActivity
import uz.raqamlar.data.BankApps
import uz.raqamlar.data.KartotekaRepo
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.PaymentSession
import uz.raqamlar.utils.PrefsHelper
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.SumUtils
import uz.raqamlar.utils.TextUtils
import uz.raqamlar.utils.VolumeKeyHandler

// Ilovaning hamma joyida ishlatiladigan umumiy oynalar va amallar (plagindagi menyularga mos)
object Flows {

    fun hook(d: AlertDialog, act: MainActivity): AlertDialog {
        d.setOnKeyListener { _, _, event -> VolumeKeyHandler.handle(act, event, d.window?.decorView) }
        return d
    }

    fun show(act: MainActivity, b: AlertDialog.Builder): AlertDialog {
        val d = hook(b.create(), act)
        d.show()
        return d
    }

    // ---------- oddiy amallar ----------

    fun call(ctx: Context, num: String) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Say.show(ctx, "Qo'ng'iroq qilib bo'lmadi")
        }
    }

    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("l", text))
    }

    private fun localDigits(num: String): String =
        num.replace(Regex("[^\\d]"), "").removePrefix("998")

    private fun openUri(ctx: Context, uri: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Say.show(ctx, "Ilova topilmadi")
        }
    }

    fun telegram(ctx: Context, num: String) = openUri(ctx, "tg://resolve?phone=998" + localDigits(num))

    fun whatsapp(ctx: Context, num: String) =
        openUri(ctx, "https://api.whatsapp.com/send?phone=998" + localDigits(num))

    fun sms(ctx: Context, num: String) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Say.show(ctx, "Xabar ilovasi topilmadi")
        }
    }

    // Operator darajasidagi video qo'ng'iroq (TelecomManager orqali)
    fun placeVideoCall(ctx: Context, num: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                val extras = Bundle()
                extras.putInt(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, VideoProfile.STATE_BIDIRECTIONAL)
                tm.placeCall(Uri.parse("tel:$num"), extras)
            } else {
                Say.show(ctx, "Video qo'ng'iroq amalga oshmadi")
            }
        } catch (e: Exception) {
            Say.show(ctx, "Video qo'ng'iroq amalga oshmadi")
        }
    }

    fun saveContact(act: MainActivity, num: String) {
        val existing = ContactUtils.findContactName(act, num)
        if (existing != null) {
            Say.show(act, "Bu raqam $existing nomi bilan oldin saqlangan", true)
            return
        }
        val edit = EditText(act)
        edit.hint = "Ism kiriting..."
        val b = AlertDialog.Builder(act).setTitle("Ism kiriting").setView(edit)
            .setPositiveButton("Saqlash") { _, _ ->
                val name = TextUtils.capitalizeAll(edit.text.toString()).ifEmpty { "Yangi" }
                val it2 = Intent(Intent.ACTION_INSERT)
                it2.type = ContactsContract.RawContacts.CONTENT_TYPE
                it2.putExtra(ContactsContract.Intents.Insert.NAME, name)
                it2.putExtra(ContactsContract.Intents.Insert.PHONE, num)
                it2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    act.startActivity(it2)
                } catch (e: Exception) {
                    Say.show(act, "Kontaktlar ilovasi topilmadi")
                }
            }
        show(act, b)
    }

    fun executePhoneCommand(act: MainActivity, command: String, num: String) {
        when (command) {
            "telefon", "chaqirish" -> call(act, num)
            "nusxalash" -> {
                copy(act, num)
                Say.show(act, "Nusxalandi: " + TextUtils.formatPhoneForVoice(num))
            }
            "saqlash" -> saveContact(act, num)
            "telegram" -> telegram(act, num)
            "whatsapp" -> whatsapp(act, num)
            "xabar" -> sms(act, num)
            "video" -> {
                Say.show(act, "Video qo'ng'iroq qilinmoqda")
                placeVideoCall(act, num)
            }
            "to'lov", "o'tkazma" -> {
                PaymentSession.data = num
                showSummaDialog(act, num)
            }
        }
    }

    // ---------- to'lov: summa -> bank ilovasi ----------

    fun showSummaDialog(act: MainActivity, data: String) {
        val layout = LinearLayout(act)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(40, 20, 40, 20)
        val edit = EditText(act)
        edit.inputType = InputType.TYPE_CLASS_NUMBER
        edit.hint = "Summani kiriting..."
        val words = TextView(act)
        words.setPadding(0, 10, 0, 10)
        layout.addView(edit)
        layout.addView(words)
        edit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                words.text = SumUtils.sumToWords(s?.toString() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        val b = AlertDialog.Builder(act).setTitle("Summani kiriting").setView(layout)
            .setPositiveButton("Davom etish") { _, _ ->
                val t = edit.text.toString()
                PaymentSession.summa = if (t.isEmpty()) null else t
                showBankMenu(act, data)
            }
            .setNegativeButton("Bekor qilish") { _, _ ->
                PaymentSession.clear()
                Say.show(act, "Bekor qilindi")
            }
        show(act, b)
    }

    fun showBankMenu(act: MainActivity, data: String) {
        val banks = BankApps.listBanks(act)
        val items = ArrayList<String>()
        for (a in banks) items.add(a.label)
        items.add("Ilova qo'shish")
        items.add("Olib tashlash")
        val b = AlertDialog.Builder(act).setTitle("Ilova tanlang")
            .setItems(items.toTypedArray()) { dialog, which ->
                if (which == banks.size) {
                    dialog.dismiss()
                    showSearchAppDialog(act, data)
                } else if (which == banks.size + 1) {
                    dialog.dismiss()
                    showHideDialog(act, data, banks)
                } else {
                    val app = banks[which]
                    val intent = act.packageManager.getLaunchIntentForPackage(app.pkg)
                    if (intent != null) {
                        PaymentSession.data = data
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        dialog.dismiss()
                        act.startActivity(intent)
                    }
                }
            }
        show(act, b)
    }

    private fun showHideDialog(act: MainActivity, data: String, banks: List<BankApps.AppInfo>) {
        val labels = ArrayList<String>()
        for (a in banks) labels.add(a.label)
        val b = AlertDialog.Builder(act).setTitle("Yashirish")
            .setItems(labels.toTypedArray()) { _, w ->
                PrefsHelper.hideApp(act, banks[w].pkg)
                Say.show(act, "Yashirildi")
                showBankMenu(act, data)
            }
        show(act, b)
    }

    private fun showSearchAppDialog(act: MainActivity, data: String) {
        val all = BankApps.listLaunchable(act)
        val layout = LinearLayout(act)
        layout.orientation = LinearLayout.VERTICAL
        val search = EditText(act)
        search.hint = "Qidirish..."
        val lv = ListView(act)
        layout.addView(search)
        val h = (act.resources.displayMetrics.heightPixels * 0.5).toInt()
        layout.addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h))

        var shown: List<BankApps.AppInfo> = all
        fun refresh(q: String) {
            val ql = q.trim().lowercase()
            shown = if (ql.isEmpty()) all else all.filter { it.label.lowercase().contains(ql) }
            val labels = ArrayList<String>()
            for (a in shown) labels.add(a.label)
            lv.adapter = ArrayAdapter(act, android.R.layout.simple_list_item_1, labels)
        }
        refresh("")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { refresh(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        val dlg = hook(AlertDialog.Builder(act).setTitle("Ilova tanlang").setView(layout).create(), act)
        lv.setOnItemClickListener { _, _, pos, _ ->
            val app = shown[pos]
            PrefsHelper.addApp(act, app.pkg)
            Say.show(act, "Qo'shildi")
            dlg.dismiss()
            showBankMenu(act, data)
        }
        dlg.show()
    }

    // ---------- raqam/karta uchun amallar menyusi (uzoq bosish) ----------

    fun showFinalActions(act: MainActivity, data: String, isCard: Boolean, typeName: String) {
        val display = if (isCard) TextUtils.formatCardForVoice(data) else TextUtils.formatPhoneForVoice(data)
        val options = ArrayList<String>()
        options.add("Nusxalab olish")
        if (isCard) {
            options.add("Kartotekaga saqlash")
        } else {
            options.add("Saqlash")
            options.add("Telegram")
            options.add("WhatsApp")
            options.add("Xabar jo'natish")
            options.add("Video qo'ng'iroq")
            options.add("To'lovlar")
        }
        options.add("Bekor qilish")
        val b = AlertDialog.Builder(act).setTitle("$typeName: $display")
            .setItems(options.toTypedArray()) { dialog, w ->
                when (options[w]) {
                    "Nusxalab olish" -> {
                        copy(act, data)
                        Say.show(act, "Nusxalandi")
                    }
                    "Kartotekaga saqlash" -> showKartotekaSaveDialog(act, data)
                    "To'lovlar" -> {
                        dialog.dismiss()
                        PaymentSession.data = data
                        showSummaDialog(act, data)
                    }
                    "Saqlash" -> saveContact(act, data)
                    "Telegram" -> telegram(act, data)
                    "WhatsApp" -> whatsapp(act, data)
                    "Xabar jo'natish" -> sms(act, data)
                    "Video qo'ng'iroq" -> {
                        Say.show(act, "Video qo'ng'iroq qilinmoqda")
                        placeVideoCall(act, data)
                    }
                    else -> {}
                }
            }
        show(act, b)
    }

    // ---------- kartotekaga saqlash ----------

    fun showKartotekaSaveDialog(act: MainActivity, card: String) {
        val db = KartotekaRepo.get(act)
        val owner = db.entries.firstOrNull { it.value.contains(card) }?.key
        if (owner != null) {
            Say.show(act, "Ushbu karta raqam ${owner}da mavjud")
            return
        }
        val names = db.keys.sorted()
        val layout = LinearLayout(act)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(30, 20, 30, 20)
        val btnNew = Button(act)
        btnNew.text = "Yangi ism bilan saqlash"
        val lv = ListView(act)
        lv.adapter = ArrayAdapter(act, android.R.layout.simple_list_item_1, names)
        layout.addView(btnNew)
        val h = (act.resources.displayMetrics.heightPixels * 0.4).toInt()
        layout.addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h))

        val dlg = hook(AlertDialog.Builder(act).setTitle("Kartotekaga saqlash").setView(layout).create(), act)
        btnNew.setOnClickListener {
            val ed = EditText(act)
            ed.hint = "Ismni kiriting..."
            val b2 = AlertDialog.Builder(act).setTitle("Yangi ism").setView(ed)
                .setPositiveButton("Saqlash") { _, _ ->
                    val n = TextUtils.capitalizeAll(ed.text.toString())
                    if (n.isNotEmpty()) {
                        val d2 = KartotekaRepo.get(act)
                        d2.getOrPut(n) { mutableListOf() }.add(card)
                        KartotekaRepo.save(act, d2)
                        Say.show(act, "Saqlandi")
                        dlg.dismiss()
                    }
                }
            show(act, b2)
        }
        lv.setOnItemClickListener { _, _, pos, _ ->
            val d2 = KartotekaRepo.get(act)
            d2[names[pos]]?.add(card)
            KartotekaRepo.save(act, d2)
            Say.show(act, "Saqlandi")
            dlg.dismiss()
        }
        dlg.show()
    }
}
