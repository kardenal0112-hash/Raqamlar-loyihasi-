package uz.raqamlar.data

import android.content.Context
import uz.raqamlar.utils.PrefsHelper

object BankApps {

    data class AppInfo(val label: String, val pkg: String)

    private val finKeys = listOf(
        "click", "payme", "uzum", "paynet", "tbc", "zoomrad", "milliy", "hamkor",
        "kapital", "ipakyuli", "agro", "sqb", "anor", "uzcard", "humo", "alif",
        "quant", "nasiya", "soliq", "poytaxt"
    )

    // To'lov ilovalari ro'yxati: moliyaviy kalit so'zlar + qo'lda qo'shilganlar - yashirilganlar
    fun listBanks(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val res = mutableListOf<AppInfo>()
        for (info in pm.getInstalledApplications(0)) {
            val pkg = info.packageName
            val lower = pkg.lowercase()
            val label = pm.getApplicationLabel(info).toString()
            val fin = finKeys.any { lower.contains(it) || label.lowercase().contains(it) }
            val ok = fin || lower.contains("bank") || lower.contains("pay") || PrefsHelper.isForceAdded(ctx, pkg)
            if (ok && !PrefsHelper.isHidden(ctx, pkg) && pm.getLaunchIntentForPackage(pkg) != null) {
                res.add(AppInfo(label, pkg))
            }
        }
        return res.sortedBy { it.label.lowercase() }
    }

    // "Ilova qo'shish" uchun: ochiladigan barcha ilovalar
    fun listLaunchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val res = mutableListOf<AppInfo>()
        for (info in pm.getInstalledApplications(0)) {
            val pkg = info.packageName
            if (pm.getLaunchIntentForPackage(pkg) != null) {
                res.add(AppInfo(pm.getApplicationLabel(info).toString(), pkg))
            }
        }
        return res.sortedBy { it.label.lowercase() }
    }
}
