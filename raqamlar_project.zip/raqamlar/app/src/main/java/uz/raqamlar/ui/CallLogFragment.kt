package uz.raqamlar.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import uz.raqamlar.R
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.TextUtils

class CallLogFragment : Fragment() {

    companion object {
        fun newInstance(callType: String?, title: String) = CallLogFragment().apply {
            arguments = Bundle().apply {
                callType?.let { putString("callType", it) }
                putString("title", title)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_call_log, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val title = arguments?.getString("title") ?: "Qo'ng'iroqlar"
        val callType = arguments?.getString("callType")

        view.announceForAccessibility(title)
        view.findViewById<TextView>(R.id.tvCallLogTitle).text = title

        val list = ContactUtils.getCallLogList(requireContext(), callType)
        if (list.isEmpty()) {
            view.findViewById<TextView>(R.id.tvEmpty).visibility = View.VISIBLE
            return
        }

        val display = list.map { e ->
            if (e.name.isNotEmpty()) "${e.name}: ${TextUtils.formatPhoneForVoice(e.num)}"
            else TextUtils.formatPhoneForVoice(e.num)
        }
        val lv = view.findViewById<ListView>(R.id.listCallLog)
        lv.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, display)

        lv.setOnItemClickListener { _, _, pos, _ ->
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${list[pos].num}"))
                .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            showActions(list[pos].num, list[pos].name); true
        }
    }

    private fun showActions(num: String, name: String) {
        val displayName = name.ifEmpty { TextUtils.formatPhoneForVoice(num) }
        val options = arrayOf(
            "Qo'ng'iroq qilish", "Nusxalab olish", "Telegram",
            "WhatsApp", "Xabar jo'natish", "Kontaktga saqlash", "To'lov / O'tkazma"
        )
        AlertDialog.Builder(requireContext()).setTitle(displayName).setItems(options) { _, w ->
            when (w) {
                0 -> startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                1 -> {
                    val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("l", num))
                    Toast.makeText(requireContext(), "Nusxalandi", Toast.LENGTH_SHORT).show()
                }
                2 -> {
                    val n = num.replace(Regex("[^\\d]"), "").removePrefix("998")
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                }
                3 -> {
                    val n = num.replace(Regex("[^\\d]"), "").removePrefix("998")
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=998$n")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                }
                4 -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                5 -> {
                    val ed = EditText(requireContext()).apply {
                        hint = "Ismni kiriting..."
                        if (name.isNotEmpty()) setText(name)
                    }
                    AlertDialog.Builder(requireContext()).setTitle("Ism kiriting").setView(ed)
                        .setPositiveButton("Saqlash") { _, _ ->
                            val n2 = TextUtils.capitalizeFirst(ed.text.toString()).ifEmpty { "Yangi" }
                            val it2 = Intent(Intent.ACTION_INSERT).apply {
                                type = android.provider.ContactsContract.RawContacts.CONTENT_TYPE
                                putExtra(android.provider.ContactsContract.Intents.Insert.NAME, n2)
                                putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, num)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            startActivity(it2)
                        }.show()
                }
                6 -> {
                    val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("l", num))
                    Toast.makeText(requireContext(), "Raqam nusxalandi. Bank ilovasini oching va maydonga joylang.", Toast.LENGTH_LONG).show()
                }
            }
        }.show()
    }
}
