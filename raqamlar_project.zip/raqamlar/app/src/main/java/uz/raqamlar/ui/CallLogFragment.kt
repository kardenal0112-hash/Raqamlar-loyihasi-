package uz.raqamlar.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.Fragment
import uz.raqamlar.MainActivity
import uz.raqamlar.R
import uz.raqamlar.utils.ContactUtils
import uz.raqamlar.utils.Say
import uz.raqamlar.utils.TextUtils

class CallLogFragment : Fragment() {

    companion object {
        fun newInstance(callType: String?, title: String) = CallLogFragment().apply {
            arguments = Bundle().apply {
                callType?.let { putString("callType", it) }
                putString("title", title)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_call_log, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val title = arguments?.getString("title") ?: "Qo'ng'iroqlar"
        val callType = arguments?.getString("callType")

        view.announceForAccessibility(title)
        val tvTitle = view.findViewById<TextView>(R.id.tvCallLogTitle)
        tvTitle.text = title
        tvTitle.contentDescription = title + ". Raqamni bosish — qo'ng'iroq qilish. Bosib ushlab turish — boshqa amallar."

        val list = ContactUtils.getCallLogList(requireContext(), callType)
        if (list.isEmpty()) {
            view.findViewById<TextView>(R.id.tvEmpty).visibility = View.VISIBLE
            return
        }

        val display = list.map { e ->
            if (e.name.isNotEmpty()) "${e.name}: ${TextUtils.formatPhoneForVoice(e.num)}"
            else TextUtils.formatPhoneForVoice(e.num)
        }
        val lv = view.findViewById<ListView>(R.id.listCallLog)
        lv.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, display)

        lv.setOnItemClickListener { _, _, pos, _ ->
            val e = list[pos]
            val shown = if (e.name.isNotEmpty()) e.name else TextUtils.formatPhoneForVoice(e.num)
            Say.show(requireContext(), "$shown, qo'ng'iroq qilinmoqda")
            Flows.call(requireContext(), e.num)
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            val e = list[pos]
            Flows.showFinalActions(activity as MainActivity, e.num, false, if (e.name.isNotEmpty()) e.name else "Raqam")
            true
        }
    }
}
