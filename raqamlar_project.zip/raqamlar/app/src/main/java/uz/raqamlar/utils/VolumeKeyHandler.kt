package uz.raqamlar.utils

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import android.view.View
import uz.raqamlar.MainActivity

// "Ovozni kamaytirish" tugmasini uzoq bosishni aniqlaydi.
// Qisqa bosish telefon tizimiga o'zgarishsiz o'tkaziladi. Uzoq bosish aniqlansa,
// o'zgargan ovoz darajalari avvalgi holiga qaytariladi va qolgan takroriy xabarlar yutiladi.
object VolumeKeyHandler {

    private var fired = false
    private var saved: IntArray? = null

    // 10 = ekran o'quvchi (accessibility) ovoz oqimi
    private val streams = intArrayOf(
        AudioManager.STREAM_MUSIC,
        AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_SYSTEM,
        AudioManager.STREAM_ALARM,
        AudioManager.STREAM_VOICE_CALL,
        10
    )

    fun handle(act: MainActivity, event: KeyEvent, root: View?): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!PrefsHelper.isVolumeKeys(act)) return false
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                fired = false
                saved = readAll(am)
                return false
            }
            if (!fired) {
                fired = true
                restore(am)
                act.onVolumeDownLongPress(root)
            }
            return true
        }

        if (event.action == KeyEvent.ACTION_UP) {
            if (fired) {
                fired = false
                restore(am)
                return true
            }
        }
        return false
    }

    private fun readAll(am: AudioManager): IntArray {
        val arr = IntArray(streams.size)
        for (i in streams.indices) {
            arr[i] = try {
                am.getStreamVolume(streams[i])
            } catch (e: Exception) {
                -1
            }
        }
        return arr
    }

    private fun restore(am: AudioManager) {
        val s = saved ?: return
        for (i in streams.indices) {
            if (s[i] < 0) continue
            try {
                if (am.getStreamVolume(streams[i]) != s[i]) {
                    am.setStreamVolume(streams[i], s[i], 0)
                }
            } catch (e: Exception) {
                // ba'zi oqimlar (masalan, "Bezovta qilmang" rejimida) o'zgartirishga ruxsat bermaydi
            }
        }
    }
}
