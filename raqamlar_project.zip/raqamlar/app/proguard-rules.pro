# Raqamlar ilova uchun ProGuard qoidalari
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
